﻿$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path;$cfg=Get-Content (Join-Path $base 'config.json') -Raw|ConvertFrom-Json
$share=$cfg.sharedRoot;$historyRoot=$cfg.historyRoot;$desktop=$cfg.desktopRoot;$agent=if($cfg.agent){$cfg.agent}else{$env:USERNAME};$db=Join-Path $base 'data\pilotage.json';if(!(Test-Path $db)){'[]'|Set-Content $db}
function Log{@(Get-Content $db -Raw|ConvertFrom-Json)};function Save($x){@($x)|ConvertTo-Json -Depth 8|Set-Content $db -Encoding UTF8}
function SN($n){switch -Regex ($n.ToUpper()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function ID($p){$s=[Security.Cryptography.SHA1]::Create();([BitConverter]::ToString($s.ComputeHash([Text.Encoding]::UTF8.GetBytes($p.ToLower())))).Replace('-','')}
function Scan{
    $a = @()
    if(!(Test-Path -LiteralPath $share -PathType Container)){ throw "Racine partagee introuvable : $share" }

    # Parcours manuel : profondeur illimitee avant le dossier de statut.
    # Des qu'un dossier A TRAITER / EN COURS / NON CONFORME / TRAITES est trouve,
    # on lit ses enfants comme dossiers de travail et on ne descend pas plus bas.
    $todo = New-Object System.Collections.Queue
    $todo.Enqueue((Get-Item -LiteralPath $share -Force))

    while($todo.Count -gt 0){
        $dir = $todo.Dequeue()
        $children = @()
        try { $children = @(Get-ChildItem -LiteralPath $dir.FullName -Force -ErrorAction Stop) }
        catch { Write-Host "Scan ignore : $($dir.FullName) - $($_.Exception.Message)" -ForegroundColor Yellow; continue }

        foreach($child in $children){
            if(!$child.PSIsContainer){ continue }
            $st = SN $child.Name

            if($st){
                if($st -eq 'TRAITES'){ continue }
                $sd = $child
                $workItems = @()
                try { $workItems = @(Get-ChildItem -LiteralPath $sd.FullName -Force -ErrorAction Stop) }
                catch { Write-Host "Statut ignore : $($sd.FullName) - $($_.Exception.Message)" -ForegroundColor Yellow; continue }

                $parentPath = $sd.Parent.FullName
                $rel = if($parentPath.Length -ge $share.Length){ $parentPath.Substring($share.Length).TrimStart('\') }else{ '' }
                $parts = @($rel -split '\\' | Where-Object { $_ })

                foreach($wi in $workItems){
                    $a += [pscustomobject]@{
                        id        = ID $wi.FullName
                        name      = $wi.Name
                        fullPath  = $wi.FullName
                        status    = $st
                        statusDir = $sd.FullName
                        domain    = if($parts.Count -gt 0){ $parts[0] }else{ '' }
                        subdomain = if($parts.Count -gt 1){ $parts[1..($parts.Count-1)] -join ' / ' }else{ '' }
                    }
                }
                continue
            }

            $todo.Enqueue($child)
        }
    }
    ,@($a)
}
function Item($id){Scan|? id -eq $id|select -First 1};function Peer($x,$n){$p=Join-Path (Split-Path $x.statusDir -Parent) $n;if(!(Test-Path $p)){mkdir $p|Out-Null};$p}
function Move($s,$d){$t=Join-Path $d (Split-Path $s -Leaf);if(Test-Path $t){throw"Destination existe déjà : $t"};Move-Item -LiteralPath $s -Destination $d;$t}
function Body($q){$r=New-Object IO.StreamReader($q.InputStream);$s=$r.ReadToEnd();$r.Close();$s|ConvertFrom-Json}
function Send($r,$o,$code=200){$j=$o|ConvertTo-Json -Depth 8;$b=[Text.Encoding]::UTF8.GetBytes($j);$r.StatusCode=$code;$r.ContentType='application/json';$r.Headers['Access-Control-Allow-Origin']='*';$r.OutputStream.Write($b,0,$b.Length);$r.Close()}
function Min($a,$b){[math]::Round(((Get-Date $b)-(Get-Date $a)).TotalMinutes,2)}
$h=New-Object Net.HttpListener;$h.Prefixes.Add('http://localhost:8090/');$h.Start();Write-Host "Accessibility Hub OK http://localhost:8090/" -ForegroundColor Green
while($h.IsListening){$c=$h.GetContext();$q=$c.Request;$r=$c.Response;try{$r.Headers['Access-Control-Allow-Origin']='*';$r.Headers['Access-Control-Allow-Headers']='Content-Type';if($q.HttpMethod-eq'OPTIONS'){$r.Close();continue};$p=$q.Url.AbsolutePath
if($p-eq'/api/config'){Send $r @{agent=$agent};continue};if($p-eq'/api/scan'){Send $r @{items=@(Scan)};continue};if($p-eq'/api/history'){Send $r @{items=@(Log|? agent -eq $agent)};continue}
if($p-eq'/api/take'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'A_TRAITER'){throw'Item invalide'};$new=Move $x.fullPath (Peer $x 'EN COURS');$now=(Get-Date).ToString('o');$l=@(Log);$l+=[pscustomobject]@{recordId=[guid]::NewGuid().ToString();name=$x.name;domain=$x.domain;subdomain=$x.subdomain;agent=$agent;dateEnCours=$now;dateFin=$null;dateRetraitement=$null;status='EN_COURS';status2=$null;dmtMinutes=$null;dmt2Minutes=$null;comment=''};Save $l;Send $r @{ok=$true};continue}
if($p-eq'/api/finish'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'EN_COURS'){throw'Item invalide'};$folder=Join-Path $desktop $b.desktopFolder;if(!(Test-Path $folder -PathType Container)){throw"Dossier Bureau introuvable"};$expected=[IO.Path]::GetFileNameWithoutExtension($x.name);if((Split-Path $folder -Leaf)-notin @($expected,$x.name)){throw"Le dossier Bureau doit avoir le nom : $expected"};$dest=if($b.status-eq'TRAITES'){'TRAITES'}else{'NON CONFORME'};Move $folder (Peer $x $dest)|Out-Null;$hd=Join-Path $historyRoot $x.domain;mkdir $hd -Force|Out-Null;Move $x.fullPath $hd|Out-Null;$now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name-and$_.status-eq'EN_COURS'}|select -Last 1;if(!$rec){throw'Journal EN_COURS introuvable'};$rec.dateFin=$now;$rec.dmtMinutes=Min $rec.dateEnCours $now;$rec.status=$b.status;$rec.comment=$b.comment;Save $l;Send $r @{ok=$true};continue}
if($p-eq'/api/rework'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'NON_CONFORME'){throw'Item invalide'};$folder=Join-Path $desktop $b.desktopFolder;if(!(Test-Path $folder -PathType Container)){throw'Dossier Bureau introuvable'};Move $folder (Peer $x 'TRAITES')|Out-Null;$arc=Join-Path $historyRoot 'NON_CONFORME_ARCHIVE';mkdir $arc -Force|Out-Null;Move $x.fullPath $arc|Out-Null;$now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name}|select -Last 1;$rec.dateRetraitement=$now;$rec.dmt2Minutes=Min $rec.dateFin $now;$rec.status2='NON_CONFORME -> TRAITES';$rec.status='TRAITES';Save $l;Send $r @{ok=$true};continue}
if($p-eq'/api/export-csv'){$csv=@(Log|? agent -eq $agent)|select name,domain,subdomain,status,status2,dateEnCours,dateFin,dateRetraitement,agent,dmtMinutes,dmt2Minutes,comment|ConvertTo-Csv -NoTypeInformation -Delimiter ';';$bb=[Text.Encoding]::UTF8.GetBytes($csv-join"`r`n");$r.ContentType='text/csv';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.OutputStream.Write($bb,0,$bb.Length);$r.Close();continue};Send $r @{error='Route inconnue'} 404}catch{try{Send $r @{error=$_.Exception.Message} 500}catch{};Write-Host $_.Exception.Message -ForegroundColor Red}}