const API='http://localhost:8080/api';let drafts=[];let cacheAssignments=[],cacheTreatments=[],currentSource={};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot',"'":'&#39;'}[c]));
const keyOf=x=>[x.agent,x.siret,x.raisonSociale].map(v=>String(v??'').trim().toUpperCase()).join('|');
function show(id,b){document.querySelectorAll('main section').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active'));b?.classList.add('active');if(id==='dash')setTimeout(drawCharts,30)}
async function test(){try{let r=await fetch(API+'/test');if(!r.ok)throw 0;backend.innerHTML='<i></i> Backend connecté';backend.classList.add('online')}catch{backend.textContent='● Backend inaccessible'}}
function addDraft(o={}){let x={id:crypto.randomUUID(),siret:o.siret??siret.value,raisonSociale:o.raisonSociale??raison.value,typeFacture:o.typeFacture??type.value,dateLimite:o.dateLimite??date.value,commentaire:o.commentaire??comment.value,agent:o.agent??agent.value,source:o.source??{...currentSource},status:'AFFECTEE'};if(drafts.some(d=>keyOf(d)===keyOf(x)))return;drafts.push(x);renderDrafts()}
function renderDrafts(){draftRows.innerHTML=drafts.map((x,i)=>`<tr><td>${esc(x.siret)}</td><td><b>${esc(x.raisonSociale)}</b></td><td>${esc(x.typeFacture)}</td><td>${esc(x.dateLimite)}</td><td><select onchange="drafts[${i}].agent=this.value"><option ${x.agent==='HAMDANMO'?'selected':''}>HAMDANMO</option><option ${x.agent==='YASSINE'?'selected':''}>YASSINE</option><option ${x.agent==='SARA'?'selected':''}>SARA</option></select></td><td><button class="icon-btn" onclick="drafts.splice(${i},1);renderDrafts()">×</button></td></tr>`).join('');draftCount.textContent=drafts.length}
async function sendAssignments(){if(!drafts.length)return alert('Aucune ligne.');try{let r=await fetch(API+'/assignments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({assignments:drafts})}),data=await r.json();if(!r.ok)throw new Error(data?.message||('HTTP '+r.status));drafts=[];renderDrafts();await loadAssignments();alert(`${data.added} affectation(s) ajoutée(s). ${data.duplicatesRemoved||0} doublon(s) ignoré(s). Total actif : ${data.count}`)}catch(e){alert('Erreur serveur : '+e.message)}}
async function loadAssignments(){try{cacheAssignments=await (await fetch(API+'/assignments?x='+Date.now())).json();activeRows.innerHTML=cacheAssignments.length?cacheAssignments.map(x=>`<tr><td><span class="avatar">${esc(x.agent).slice(0,2)}</span>${esc(x.agent)}</td><td>${esc(x.siret)}</td><td><b>${esc(x.raisonSociale)}</b></td><td><span class="badge">${esc(x.status)}</span></td></tr>`).join(''):'<tr><td colspan="4" class="table-empty">Aucune affectation active</td></tr>';updateKPIs()}catch{}}
async function loadTreatments(){try{let raw=await (await fetch(API+'/treatments?x='+Date.now())).json(),m=new Map();for(const x of raw){let k=keyOf(x),old=m.get(k);if(!old||new Date(x.completedAt||0)>new Date(old.completedAt||0))m.set(k,x)}cacheTreatments=[...m.values()];treatRows.innerHTML=cacheTreatments.length?cacheTreatments.map(x=>`<tr><td><span class="avatar">${esc(x.agent).slice(0,2)}</span>${esc(x.agent)}</td><td><b>${esc(x.raisonSociale)}</b><div class="muted">${esc(x.siret)}</div></td><td>${esc(x.numeroAbonne)}</td><td>${esc(x.idt)}</td><td>${esc(x.contratBAD)}</td><td><span class="badge ${x.status==='VALIDEE'?'valid':x.status==='A_CORRIGER'?'correction':''}">${esc(x.status||'A_VERIFIER')}</span></td><td class="actions"><button class="ok small" onclick="statusChange('${x.assignmentId}','VALIDEE')">Valider</button><button class="warn small" onclick="correct('${x.assignmentId}')">Corriger</button></td></tr>`).join(''):'<tr><td colspan="7" class="table-empty">Aucun traitement reçu</td></tr>';updateKPIs()}catch{}}
function updateKPIs(){kActive.textContent=cacheAssignments.length;kReceived.textContent=cacheTreatments.length;kVerify.textContent=cacheTreatments.filter(x=>(x.status||'A_VERIFIER')==='A_VERIFIER').length;kValid.textContent=cacheTreatments.filter(x=>x.status==='VALIDEE').length;drawCharts()}
async function statusChange(id,status,comment=''){await fetch(API+'/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({assignmentId:id,status,comment})});await refreshAll()}
function correct(id){let c=prompt('Commentaire de correction pour l’agent :','');if(c!==null)statusChange(id,'A_CORRIGER',c)}
async function refreshAll(){await loadAssignments();await loadTreatments()}
function drawDonut(canvas,vals,labels){let c=canvas,ctx=c.getContext('2d'),dpr=devicePixelRatio||1,w=c.clientWidth||360,h=c.clientHeight||230;c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);let total=vals.reduce((a,b)=>a+b,0)||1,cx=w*.34,cy=h*.5,r=Math.min(w,h)*.28,start=-Math.PI/2,colors=['#0b8062','#163f58','#d9a441','#dce8e4'];vals.forEach((v,i)=>{let a=v/total*Math.PI*2;ctx.beginPath();ctx.strokeStyle=colors[i];ctx.lineWidth=22;ctx.arc(cx,cy,r,start,start+a);ctx.stroke();start+=a});ctx.fillStyle='#12201d';ctx.font='700 25px Segoe UI';ctx.textAlign='center';ctx.fillText(String(vals.reduce((a,b)=>a+b,0)),cx,cy+7);ctx.textAlign='left';ctx.font='600 12px Segoe UI';labels.forEach((l,i)=>{let y=50+i*35;ctx.fillStyle=colors[i];ctx.fillRect(w*.68,y-9,10,10);ctx.fillStyle='#60716c';ctx.fillText(l+'  '+vals[i],w*.68+18,y)})}
function drawBars(canvas,groups){let c=canvas,ctx=c.getContext('2d'),dpr=devicePixelRatio||1,w=c.clientWidth||500,h=c.clientHeight||230;c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);let max=Math.max(1,...groups.map(x=>x.v)),base=h-35,bw=Math.min(58,(w-70)/Math.max(groups.length,1)*.45);ctx.strokeStyle='#e5ece9';ctx.beginPath();ctx.moveTo(38,18);ctx.lineTo(38,base);ctx.lineTo(w-12,base);ctx.stroke();groups.forEach((g,i)=>{let x=55+i*((w-80)/groups.length),bh=(base-30)*g.v/max;ctx.fillStyle='#0b8062';ctx.fillRect(x,base-bh,bw,bh);ctx.fillStyle='#60716c';ctx.font='600 11px Segoe UI';ctx.fillText(g.n.slice(0,10),x,base+18);ctx.fillStyle='#12201d';ctx.fillText(g.v,x+bw/2-3,base-bh-8)})}
function drawCharts(){if(!document.getElementById('statusChart'))return;let verify=cacheTreatments.filter(x=>(x.status||'A_VERIFIER')==='A_VERIFIER').length,valid=cacheTreatments.filter(x=>x.status==='VALIDEE').length,corr=cacheTreatments.filter(x=>x.status==='A_CORRIGER').length;drawDonut(statusChart,[cacheAssignments.length,verify,valid,corr],['Actives','À vérifier','Validées','Corrections']);let names=[...new Set([...cacheAssignments,...cacheTreatments].map(x=>x.agent))];drawBars(agentChart,names.map(n=>({n,v:cacheTreatments.filter(x=>x.agent===n).length})))}
function exportDashboard(){let rows=cacheTreatments.map(x=>({Agent:x.agent,SIRET:x.siret,'Raison sociale':x.raisonSociale,'N° Abonné':x.numeroAbonne,IDT:x.idt,MDP:x.mdp,'Contrat BAD':x.contratBAD,CSP:x.csp,Commentaire:x.commentaire,Statut:x.status||'A_VERIFIER','Terminé le':x.completedAt}));let wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(rows);XLSX.utils.book_append_sheet(wb,ws,'Traitements');let summary=[['ÉPITHÈTE - Tableau de bord','Valeur'],['Affectations actives',cacheAssignments.length],['Traitements reçus',cacheTreatments.length],['À vérifier',cacheTreatments.filter(x=>(x.status||'A_VERIFIER')==='A_VERIFIER').length],['Validés',cacheTreatments.filter(x=>x.status==='VALIDEE').length],['À corriger',cacheTreatments.filter(x=>x.status==='A_CORRIGER').length]];XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(summary),'Dashboard');XLSX.writeFile(wb,'EPITHETE_TDB_'+new Date().toISOString().slice(0,10)+'.xlsx')}
function norm(v){return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase()}
function excelDate(v){
  if(v===null||v===undefined||v==='')return '';
  if(v instanceof Date && !isNaN(v))return v.toLocaleDateString('fr-FR');
  if(typeof v==='number' && v>20000 && v<80000){
    const d=XLSX.SSF.parse_date_code(v);
    if(d)return String(d.d).padStart(2,'0')+'/'+String(d.m).padStart(2,'0')+'/'+d.y;
  }
  return String(v);
}
function findSourceValue(rows,patterns){
  for(let r=0;r<Math.min(rows.length,30);r++){
    for(let c=0;c<Math.min((rows[r]||[]).length,8);c++){
      const label=norm(rows[r][c]);
      if(patterns.some(rx=>rx.test(label))){
        for(let j=c+1;j<Math.min((rows[r]||[]).length,c+4);j++){
          const v=rows[r][j];
          if(v!==''&&v!==null&&v!==undefined)return String(v);
        }
        if(rows[r+1]){
          const v=rows[r+1][c];
          if(v!==''&&v!==null&&v!==undefined)return String(v);
        }
      }
    }
  }
  return '';
}
excel.addEventListener('change',async e=>{
  let f=e.target.files[0];if(!f)return;
  let wb=XLSX.read(await f.arrayBuffer(),{type:'array',cellDates:false}),ws=wb.Sheets[wb.SheetNames[0]],
      rows=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:true});
  currentSource={
    nomCSP: findSourceValue(rows,[/^coordonnees du csp$/, /^nom csp$/, /^csp$/]) || String(rows?.[0]?.[0]||'').trim(),
    contratBAD: findSourceValue(rows,[/^contrat b@?d$/, /^contrat bad$/]),
    idtConnexion: findSourceValue(rows,[/^idt de connexion$/, /^idt connexion$/, /^identifiant de connexion$/]),
    mdpCSP: findSourceValue(rows,[/^mdp csp$/, /^mot de passe csp$/]),
    numeroAbonneCSP: findSourceValue(rows,[/^n.? abonne csp$/, /^numero abonne csp$/]),
    ibanPrelevement: findSourceValue(rows,[/^iban de prelevement$/, /^iban prelevement$/])
  };
  // Le nom CSP est souvent le titre en haut à gauche (ex. CYBERG)
  if(!currentSource.nomCSP || /coordonnees/i.test(currentSource.nomCSP)){
    for(let r=0;r<Math.min(8,rows.length);r++){
      let v=String(rows[r]?.[0]||'').trim();
      if(v && !/coordonnees|contrat|idt|mdp|abonne|iban/i.test(norm(v))){currentSource.nomCSP=v;break}
    }
  }
  let hi=rows.findIndex(r=>r.some(v=>/siret/i.test(String(v)))&&r.some(v=>/raison/i.test(String(v))));
  if(hi<0)return alert('En-têtes SIRET / Raison sociale non détectés.');
  let h=rows[hi].map(v=>String(v).trim()),ix=p=>h.findIndex(v=>p.test(v)),
      si=ix(/siret/i),ri=ix(/raison/i),ti=ix(/facture|e\/r|emission|réception|reception/i),
      di=ix(/date limite/i),ci=ix(/comment/i);
  rows.slice(hi+1).filter(r=>r[si]||r[ri]).forEach(r=>addDraft({
    siret:r[si],raisonSociale:r[ri],typeFacture:ti>=0?r[ti]:'',
    dateLimite:di>=0?excelDate(r[di]):'',commentaire:ci>=0?r[ci]:'',
    agent:'HAMDANMO',source:{...currentSource}
  }));
  if(document.getElementById('sourcePreview')){
    sourcePreview.innerHTML=`<b>${esc(currentSource.nomCSP||'Source détectée')}</b> · Contrat BAD: ${esc(currentSource.contratBAD||'-')} · IDT: ${esc(currentSource.idtConnexion||'-')} · N° Abonné CSP: ${esc(currentSource.numeroAbonneCSP||'-')}`;
  }
});
test();refreshAll();
