$ErrorActionPreference = "Stop"
$port = 8080
$baseUrl = "http://localhost:$port/"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $root "data"
$consolidDir = Join-Path $dataDir "consolid"
$affFile = Join-Path $dataDir "affectations.js"
$dbFile = Join-Path $dataDir "manager-db.json"
New-Item -ItemType Directory -Force -Path $dataDir,$consolidDir | Out-Null
if (!(Test-Path $dbFile)) { '{"history":[],"validations":{}}' | Set-Content $dbFile -Encoding UTF8 }
if (!(Test-Path $affFile)) { 'window.AFFECTATIONS = { generatedAt: "", assignments: [] };' | Set-Content $affFile -Encoding UTF8 }

function SendJson($res,$obj,[int]$code=200){
  $json=$obj|ConvertTo-Json -Depth 40; $b=[Text.Encoding]::UTF8.GetBytes($json)
  $res.StatusCode=$code; $res.ContentType='application/json; charset=utf-8'
  $res.Headers['Access-Control-Allow-Origin']='*'; $res.Headers['Access-Control-Allow-Methods']='GET,POST,OPTIONS'; $res.Headers['Access-Control-Allow-Headers']='Content-Type'
  $res.ContentLength64=$b.Length; $res.OutputStream.Write($b,0,$b.Length); $res.Close()
}
function Body($req){ $r=New-Object IO.StreamReader($req.InputStream,$req.ContentEncoding); $s=$r.ReadToEnd();$r.Close(); if($s){$s|ConvertFrom-Json}else{$null} }
function Norm($v){ if($null -eq $v){return ''}; return ([string]$v).Trim().ToUpperInvariant() }
function WorkKey($x){ return (Norm $x.agent)+'|'+(Norm $x.siret)+'|'+(Norm $x.raisonSociale) }
function ReadDb { try { return (Get-Content $dbFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return [pscustomobject]@{history=@();validations=[pscustomobject]@{}} } }
function SaveDb($db){ $db|ConvertTo-Json -Depth 40|Set-Content $dbFile -Encoding UTF8 }
function ReadAssignments {
  $s=Get-Content $affFile -Raw -Encoding UTF8; $s=$s -replace '^\s*window\.AFFECTATIONS\s*=\s*','' -replace ';\s*$',''
  if([string]::IsNullOrWhiteSpace($s)){return @()}; $o=$s|ConvertFrom-Json; return @($o.assignments)
}
function DedupAssignments($items){
  $seen=@{}; $out=@(); foreach($x in @($items)){
    $k=WorkKey $x; if([string]::IsNullOrWhiteSpace($k)){continue}
    if(-not $seen.ContainsKey($k)){ $seen[$k]=$true; $out+=@($x) }
  }; return @($out)
}
function WriteAssignments($a){ $clean=DedupAssignments $a; $o=[ordered]@{generatedAt=(Get-Date).ToString('s');assignments=@($clean)}; ('window.AFFECTATIONS = '+($o|ConvertTo-Json -Depth 40)+';')|Set-Content $affFile -Encoding UTF8 }
function ReadConsolid {
  $byKey=@{}
  Get-ChildItem $consolidDir -Filter '*.js' -ErrorAction SilentlyContinue | ForEach-Object {
    try {
      $s=Get-Content $_.FullName -Raw -Encoding UTF8
      $s=$s -replace '^\s*window\.(?:CONSOLID_|EPITHETE_CONSOLID_)[A-Za-z0-9_]+\s*=\s*','' -replace ';\s*$',''
      $o=$s|ConvertFrom-Json
      foreach($t in @($o.treatments)){
        if(-not $t.assignmentId){continue}
        $k=WorkKey $t
        $stamp=if($t.completedAt){[datetime]$t.completedAt}else{[datetime]::MinValue}
        if(-not $byKey.ContainsKey($k) -or $stamp -gt $byKey[$k].stamp){ $byKey[$k]=@{stamp=$stamp;item=$t} }
      }
    } catch { Write-Host "Consolidation ignoree: $($_.Name) - $($_.Exception.Message)" -ForegroundColor DarkYellow }
  }
  return @($byKey.Values | ForEach-Object {$_.item})
}
function ValidationFor($db,$id){ if($db.validations -and $db.validations.PSObject.Properties.Name -contains $id){return $db.validations.$id}; return $null }
function SyncCompleted {
  $a=DedupAssignments (ReadAssignments); $t=ReadConsolid; $db=ReadDb; $removeIds=@{}; $removeKeys=@{}
  foreach($x in $t){
    $v=ValidationFor $db $x.assignmentId; $isFresh=$true
    if($v -and $v.status -eq 'A_CORRIGER' -and $v.updatedAt -and $x.completedAt){ $isFresh=([datetime]$x.completedAt -gt [datetime]$v.updatedAt) }
    if(-not $v -or $v.status -ne 'A_CORRIGER' -or $isFresh){ $removeIds[$x.assignmentId]=$true; $removeKeys[(WorkKey $x)]=$true }
  }
  $new=@($a|Where-Object{-not $removeIds.ContainsKey($_.id) -and -not $removeKeys.ContainsKey((WorkKey $_))})
  if($new.Count -ne $a.Count){WriteAssignments $new}
  return @{assignments=$new;treatments=$t}
}

$listener=New-Object Net.HttpListener; $listener.Prefixes.Add($baseUrl)
try{$listener.Start()}catch{Write-Host "ERREUR: $($_.Exception.Message)" -ForegroundColor Red; Read-Host 'Entree'; exit}
Write-Host "EPITHETE backend OK - $baseUrl" -ForegroundColor Green
Write-Host "Dossier: $root"; Write-Host "Laisser cette fenetre ouverte." -ForegroundColor Yellow
while($listener.IsListening){
 try{
  $c=$listener.GetContext();$q=$c.Request;$r=$c.Response
  if($q.HttpMethod -eq 'OPTIONS'){$r.StatusCode=204;$r.Headers['Access-Control-Allow-Origin']='*';$r.Headers['Access-Control-Allow-Methods']='GET,POST,OPTIONS';$r.Headers['Access-Control-Allow-Headers']='Content-Type';$r.Close();continue}
  $p=$q.Url.AbsolutePath.TrimEnd('/')
  if($p -eq '/api/test'){SendJson $r @{success=$true;message='Backend EPITHETE operationnel'};continue}
  if($p -eq '/api/assignments' -and $q.HttpMethod -eq 'GET'){ $s=SyncCompleted; SendJson $r $s.assignments;continue }
  if($p -eq '/api/assignments' -and $q.HttpMethod -eq 'POST'){
    $b=Body $q; $a=@(ReadAssignments); $existing=@{}; foreach($e in $a){$existing[(WorkKey $e)]=$true}; $added=0;$duplicates=0
    foreach($x in @($b.assignments)){
      $k=WorkKey $x; if($existing.ContainsKey($k)){$duplicates++;continue}
      if(-not $x.id){$x|Add-Member -NotePropertyName id -NotePropertyValue ([guid]::NewGuid().ToString()) -Force}
      if(-not $x.status){$x|Add-Member -NotePropertyName status -NotePropertyValue 'AFFECTEE' -Force}
      $x|Add-Member -NotePropertyName assignedAt -NotePropertyValue (Get-Date).ToString('s') -Force
      $a+=@($x);$existing[$k]=$true;$added++
    }
    WriteAssignments $a; SendJson $r @{success=$true;count=@((ReadAssignments)).Count;added=$added;duplicatesRemoved=$duplicates};continue
  }
  if($p -eq '/api/treatments' -and $q.HttpMethod -eq 'GET'){
    $s=SyncCompleted; $db=ReadDb; $out=@()
    foreach($x in $s.treatments){
      $v=ValidationFor $db $x.assignmentId; $status='A_VERIFIER'
      if($v){
        if($v.status -eq 'A_CORRIGER' -and $v.updatedAt -and $x.completedAt -and ([datetime]$x.completedAt -gt [datetime]$v.updatedAt)){$status='A_VERIFIER'}else{$status=$v.status}
      }
      $x.status=$status; $out+=@($x)
    }
    SendJson $r $out;continue
  }
  if($p -eq '/api/status' -and $q.HttpMethod -eq 'POST'){
    $b=Body $q; $db=ReadDb; if(-not $db.validations){$db|Add-Member validations ([pscustomobject]@{})}
    $record=[pscustomobject]@{status=$b.status;comment=$b.comment;updatedAt=(Get-Date).ToString('o')}
    $db.validations|Add-Member -NotePropertyName $b.assignmentId -NotePropertyValue $record -Force; SaveDb $db
    if($b.status -eq 'A_CORRIGER'){
      $a=ReadAssignments; $t=(ReadConsolid|Where-Object assignmentId -eq $b.assignmentId|Select-Object -First 1)
      if($t){
        $k=WorkKey $t; if(-not (@($a|Where-Object{(WorkKey $_) -eq $k}).Count)){
          $a+= [pscustomobject]@{id=$t.assignmentId;agent=$t.agent;siret=$t.siret;raisonSociale=$t.raisonSociale;typeFacture=$t.typeFacture;dateLimite=$t.dateLimite;commentaire=('CORRECTION MANAGER : '+$b.comment);status='A_CORRIGER';assignedAt=(Get-Date).ToString('s')}
          WriteAssignments $a
        }
      }
    }
    SendJson $r @{success=$true};continue
  }
  SendJson $r @{success=$false;message='Route introuvable'} 404
 }catch{try{SendJson $r @{success=$false;message=$_.Exception.Message} 500}catch{}}
}
