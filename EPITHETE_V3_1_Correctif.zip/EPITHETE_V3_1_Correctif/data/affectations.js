window.AFFECTATIONS = { generatedAt: "", assignments: [] };
