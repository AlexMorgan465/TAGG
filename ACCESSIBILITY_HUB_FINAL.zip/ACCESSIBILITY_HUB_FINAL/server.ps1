$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg=Get-Content (Join-Path $base 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$share=$cfg.sharedRoot; $historyRoot=$cfg.historyRoot; $desktop=$cfg.desktopRoot
$agent=if($cfg.agent){$cfg.agent}else{$env:USERNAME}
$db=Join-Path $base 'data\pilotage.json'
if(!(Test-Path $db)){'[]'|Set-Content $db -Encoding UTF8}
function Log { try {@(Get-Content $db -Raw -Encoding UTF8|ConvertFrom-Json)} catch {@()} }
function Save($x){@($x)|ConvertTo-Json -Depth 10|Set-Content $db -Encoding UTF8}
function SN($n){switch -Regex ($n.ToUpper().Trim()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function StatusName($s){switch($s){'A_TRAITER'{'A TRAITER'};'EN_COURS'{'EN COURS'};'NON_CONFORME'{'NON CONFORME'};'TRAITES'{'TRAITES'}}}
function ID($p){$s=[Security.Cryptography.SHA1]::Create();try{([BitConverter]::ToString($s.ComputeHash([Text.Encoding]::UTF8.GetBytes($p.ToLowerInvariant())))).Replace('-','')}finally{$s.Dispose()}}
function RelParts($p){$rel=$p.Substring($share.TrimEnd('\').Length).TrimStart('\');@($rel -split '\\'|?{$_})}
function Scan {
  $a=@(); if(!(Test-Path -LiteralPath $share -PathType Container)){throw "Racine partagee inaccessible : $share"}
  $todo=New-Object Collections.Queue; $todo.Enqueue((Get-Item -LiteralPath $share))
  while($todo.Count){
    $dir=$todo.Dequeue(); $st=SN $dir.Name
    if($st){
      # A PUBLIER n'est jamais un statut car SN ne le reconnait pas.
      # Dans un statut, les fichiers directs = sans sous-domaine.
      # Les fichiers dans un/des sous-dossiers = sous-domaine dynamique.
      $files=@(); try{$files=@(Get-ChildItem -LiteralPath $dir.FullName -File -Recurse -Force -ErrorAction SilentlyContinue)}catch{}
      $parts=RelParts $dir.FullName; $statusIndex=$parts.Count-1
      $domain=if($statusIndex -gt 0){$parts[0]}else{''}
      foreach($f in $files){
        $inside=$f.DirectoryName.Substring($dir.FullName.Length).TrimStart('\')
        $sub=if($inside){($inside -split '\\') -join ' / '}else{''}
        $a += [pscustomobject]@{id=ID $f.FullName;name=$f.Name;fullPath=$f.FullName;status=$st;statusDir=$dir.FullName;domain=$domain;subdomain=$sub}
      }
      continue
    }
    # Ne jamais scanner A PUBLIER.
    if($dir.Name.ToUpper().Trim() -eq 'A PUBLIER'){continue}
    try{foreach($sub in @(Get-ChildItem -LiteralPath $dir.FullName -Directory -Force -ErrorAction Stop)){$todo.Enqueue($sub)}}catch{Write-Warning "Branche ignoree: $($dir.FullName)"}
  }
  ,@($a)
}
function Item($id){Scan|? id -eq $id|select -First 1}
function DestDir($x,$status){
  $domainRoot=Join-Path $share $x.domain; $p=Join-Path $domainRoot (StatusName $status)
  if($x.subdomain){foreach($part in ($x.subdomain -split ' / ')){$p=Join-Path $p $part}}
  if(!(Test-Path $p)){New-Item -ItemType Directory -Path $p -Force|Out-Null};$p
}
function MoveOne($src,$destDir){$t=Join-Path $destDir (Split-Path $src -Leaf);if(Test-Path $t){throw "Destination existe deja : $t"};Move-Item -LiteralPath $src -Destination $destDir;$t}
function ArchiveOriginal($x){$p=Join-Path $historyRoot $x.domain;if($x.subdomain){foreach($part in ($x.subdomain -split ' / ')){$p=Join-Path $p $part}};if(!(Test-Path $p)){New-Item -ItemType Directory -Path $p -Force|Out-Null};MoveOne $x.fullPath $p|Out-Null}
function Body($q){$sr=New-Object IO.StreamReader($q.InputStream);try{$s=$sr.ReadToEnd()}finally{$sr.Close()};if([string]::IsNullOrWhiteSpace($s)){return [pscustomobject]@{}};$s|ConvertFrom-Json}
function Send($r,$o,$code=200){try{$j=$o|ConvertTo-Json -Depth 10;$b=[Text.Encoding]::UTF8.GetBytes($j);$r.StatusCode=$code;$r.ContentType='application/json; charset=utf-8';$r.Headers['Access-Control-Allow-Origin']='*';$r.ContentLength64=$b.Length;$r.OutputStream.Write($b,0,$b.Length)}finally{try{$r.OutputStream.Close()}catch{};try{$r.Close()}catch{}}}
function Minutes($a,$b){if(!$a-or!$b){return $null};[math]::Round(((Get-Date $b)-(Get-Date $a)).TotalMinutes,2)}
$h=New-Object Net.HttpListener;$h.Prefixes.Add('http://localhost:8090/');$h.Start();Write-Host "Accessibility Hub OK http://localhost:8090/" -ForegroundColor Green
while($h.IsListening){$c=$h.GetContext();$q=$c.Request;$r=$c.Response;try{$r.Headers['Access-Control-Allow-Origin']='*';$r.Headers['Access-Control-Allow-Headers']='Content-Type';if($q.HttpMethod-eq'OPTIONS'){$r.Close();continue};$p=$q.Url.AbsolutePath
 if($p-eq'/api/config'){Send $r @{agent=$agent};continue}
 if($p-eq'/api/scan'){Send $r @{items=@(Scan)};continue}
 if($p-eq'/api/history'){Send $r @{items=@(Log|? agent -eq $agent)};continue}
 if($p-eq'/api/take'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'A_TRAITER'){throw'Item invalide'};MoveOne $x.fullPath (DestDir $x 'EN_COURS')|Out-Null;$now=(Get-Date).ToString('o');$l=@(Log);$l+=[pscustomobject]@{recordId=[guid]::NewGuid().ToString();name=$x.name;domain=$x.domain;subdomain=$x.subdomain;agent=$agent;dateEnCours=$now;dateFin=$null;dateRetraitement=$null;status='EN_COURS';status2=$null;dmtMinutes=$null;dmt2Minutes=$null;comment=''};Save $l;Send $r @{ok=$true};continue}
 if($p-eq'/api/finish'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'EN_COURS'){throw'Item invalide'};$folder=Join-Path $desktop $b.desktopFolder;if(!(Test-Path $folder -PathType Container)){throw'Dossier Bureau introuvable'};$expected=[IO.Path]::GetFileNameWithoutExtension($x.name);if((Split-Path $folder -Leaf)-notin @($expected,$x.name)){throw "Le dossier Bureau doit avoir le nom : $expected"};$dest=if($b.status-eq'TRAITES'){'TRAITES'}else{'NON_CONFORME'};MoveOne $folder (DestDir $x $dest)|Out-Null;ArchiveOriginal $x;$now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name-and$_.status-eq'EN_COURS'}|select -Last 1;if(!$rec){throw'Journal EN_COURS introuvable'};$rec.dateFin=$now;$rec.dmtMinutes=Minutes $rec.dateEnCours $now;$rec.status=$dest;$rec.comment=$b.comment;Save $l;Send $r @{ok=$true};continue}
 if($p-eq'/api/rework'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'NON_CONFORME'){throw'Item invalide'};$folder=Join-Path $desktop $b.desktopFolder;if(!(Test-Path $folder -PathType Container)){throw'Dossier Bureau introuvable'};MoveOne $folder (DestDir $x 'TRAITES')|Out-Null;$now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name}|select -Last 1;if(!$rec){throw'Historique introuvable'};$rec.dateRetraitement=$now;$rec.dmt2Minutes=Minutes $rec.dateFin $now;$rec.status2='NON_CONFORME -> TRAITES';$rec.status='TRAITES';Save $l;Send $r @{ok=$true};continue}
 if($p-eq'/api/export-csv'){$csv=@(Log|? agent -eq $agent)|select name,domain,subdomain,status,status2,dateEnCours,dateFin,dateRetraitement,agent,dmtMinutes,dmt2Minutes,comment|ConvertTo-Csv -NoTypeInformation -Delimiter ';';$bb=[Text.Encoding]::UTF8.GetBytes($csv-join"`r`n");$r.ContentType='text/csv; charset=utf-8';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.OutputStream.Write($bb,0,$bb.Length);$r.Close();continue}
 Send $r @{error='Route inconnue'} 404
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;try{Send $r @{error=$_.Exception.Message} 500}catch{}}}
