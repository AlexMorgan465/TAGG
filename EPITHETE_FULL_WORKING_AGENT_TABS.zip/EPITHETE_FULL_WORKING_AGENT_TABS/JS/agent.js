const AGENT=window.CURRENT_AGENT;let selected=null;const key='EPITHETE_TREATMENTS_'+AGENT;who.textContent=AGENT;agentName.textContent=AGENT;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const workKey=x=>[x.agent,x.siret,x.raisonSociale].map(v=>String(v??'').trim().toUpperCase()).join('|');
function history(){try{let a=JSON.parse(localStorage.getItem(key)||'[]'),m=new Map();for(const x of a){let k=workKey(x),old=m.get(k);if(!old||new Date(x.completedAt||0)>new Date(old.completedAt||0))m.set(k,x)}let clean=[...m.values()];if(clean.length!==a.length)localStorage.setItem(key,JSON.stringify(clean));return clean}catch{return []}}
function loadAssignments(){let done=new Set(history().map(workKey)),seen=new Set();let a=(window.AFFECTATIONS?.assignments||[]).filter(x=>{let k=workKey(x);if(x.agent!==AGENT||done.has(k)||seen.has(k))return false;seen.add(k);return true});count.textContent=a.length;list.innerHTML=a.length?a.map(x=>`<div class="assignment" onclick="pick('${x.id}',this)"><div class="assignment-top"><b>${esc(x.raisonSociale)}</b><span class="mini-badge">${esc(x.status||'AFFECTEE')}</span></div><div>SIRET : ${esc(x.siret)} · Type : ${esc(x.typeFacture)}</div><div class="muted">${esc(x.dateLimite||'')} ${x.status==='A_CORRIGER'?'· Correction demandée':''}</div></div>`).join(''):'<div class="empty"><b>Tout est à jour</b><span>Aucune affectation active.</span></div>'}
function copyText(v){let t=String(v??'');if(!t)return;navigator.clipboard?.writeText(t).catch(()=>{})}
function rowInfo(label,value){let v=value??'';return `<div class="uf-row"><span>${esc(label)}</span><b>${esc(v||'-')}</b><button class="copy-btn" onclick='copyText(${JSON.stringify(String(v))})' ${v?'':'disabled'}>Copier</button></div>`}
function pick(id,el){selected=(window.AFFECTATIONS.assignments||[]).find(x=>x.id===id);document.querySelectorAll('.assignment').forEach(x=>x.classList.remove('sel'));el.classList.add('sel');let s=selected.source||{};info.innerHTML=`<div class="info-section"><div class="info-title">Information fichier Source</div>${rowInfo('Nom CSP',s.nomCSP)}${rowInfo('Contrat BAD',s.contratBAD)}${rowInfo('IDT Connexion',s.idtConnexion)}${rowInfo('Numéro Abonné CSP',s.numeroAbonneCSP)}${rowInfo('IBAN Prélèvement',s.ibanPrelevement)}${rowInfo('MDP CSP',s.mdpCSP)}</div><div class="info-section"><div class="info-title">Information ligne sélectionnée</div>${rowInfo('Raison Sociale',selected.raisonSociale)}${rowInfo('SIRET',selected.siret)}${rowInfo('Type Facture',selected.typeFacture)}${rowInfo('Date limite',selected.dateLimite)}</div>`}
function buildTreatment(){
 if(!selected){alert('Sélectionnez une ligne.');return null}
 return {assignmentId:selected.id,agent:AGENT,siret:selected.siret,raisonSociale:selected.raisonSociale,typeFacture:selected.typeFacture,dateLimite:selected.dateLimite,source:selected.source||{},numeroAbonne:numeroAbonne.value,idt:idt.value,mdp:mdp.value,contratBAD:contratBAD.value,csp:csp.value,commentaire:commentaire.value,status:'A_VERIFIER',completedAt:new Date().toISOString()};
}
function finish(){
 let t=buildTreatment();if(!t)return;
 let arr=history(),k=workKey(selected);arr=arr.filter(x=>workKey(x)!==k);arr.push(t);localStorage.setItem(key,JSON.stringify(arr));
 selected=null;info.innerHTML='<div class="empty"><b>Aucun dossier sélectionné</b><span>Choisissez une ligne à gauche.</span></div>';
 ['numeroAbonne','idt','mdp','contratBAD','csp','commentaire'].forEach(id=>document.getElementById(id).value='');
 loadAssignments();renderHistory();showTab('history');
 alert('Traitement terminé et enregistré.');
}
function exportTreatments(){
 let arr=history();if(!arr.length)return alert('Aucun traitement à exporter.');
 let safe=AGENT.replace(/[^A-Za-z0-9_]/g,'_'),text=`window.EPITHETE_CONSOLID_${safe} = ${JSON.stringify({agent:AGENT,generatedAt:new Date().toISOString(),treatments:arr},null,2)};`;
 let blob=new Blob([text],{type:'text/javascript'}),lnk=document.createElement('a');lnk.href=URL.createObjectURL(blob);lnk.download=AGENT+'.js';lnk.click();setTimeout(()=>URL.revokeObjectURL(lnk.href),1000);
 alert('Export prêt. Remplacez '+AGENT+'.js dans data\\consolid.');
}
function renderHistory(){
 let arr=history().sort((x,y)=>new Date(y.completedAt||0)-new Date(x.completedAt||0)),hc=document.getElementById('historyCount'),hl=document.getElementById('historyList');
 if(hc)hc.textContent=arr.length;if(!hl)return;
 hl.innerHTML=arr.length?arr.map(x=>`<div class="history-item"><div class="history-top"><div><b>${esc(x.raisonSociale)}</b><small>SIRET : ${esc(x.siret)}</small></div><span class="mini-badge">${esc(x.status||'A_VERIFIER')}</span></div><div class="history-grid"><span>Type facture<b>${esc(x.typeFacture||'-')}</b></span><span>Date limite<b>${esc(x.dateLimite||'-')}</b></span><span>N° Abonné<b>${esc(x.numeroAbonne||'-')}</b></span><span>IDT<b>${esc(x.idt||'-')}</b></span><span>MDP<b>${esc(x.mdp||'-')}</b></span><span>Contrat BAD<b>${esc(x.contratBAD||'-')}</b></span><span>CSP<b>${esc(x.csp||'-')}</b></span><span>Terminé le<b>${x.completedAt?new Date(x.completedAt).toLocaleString('fr-FR'):'-'}</b></span></div>${x.commentaire?`<div class="history-comment">${esc(x.commentaire)}</div>`:''}</div>`).join(''):'<div class="empty"><b>Aucun traitement terminé</b><span>Les dossiers terminés apparaîtront ici.</span></div>';
}
function showTab(tab){
 document.querySelectorAll('.agent-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 document.getElementById('workView').hidden=tab!=='work';document.getElementById('historyView').hidden=tab!=='history';
 if(tab==='history')renderHistory();
}

loadAssignments();renderHistory();
