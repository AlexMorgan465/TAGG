ACCESSIBILITY HUB V3.10 - JOURNAL SOURCE OF TRUTH

- pilotage.json is always written as one valid JSON array.
- Atomic save via pilotage.json.tmp then replace.
- Recovery attempt for journal files produced by older builds.
- Startup log: JOURNAL -> X enregistrement(s) charges.
- /api/history log: HISTORY API -> X / Y enregistrement(s).
- TAKE and FINISH journal writes are explicitly logged.
- Frontend upserts a returned history record instead of blindly duplicating it.
- History and statistics use the same hist[] source in the browser.
