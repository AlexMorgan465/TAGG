ACCESSIBILITY HUB V2
1. Vérifier config.json (chemins réseau et agent).
2. Lancer server.ps1 dans PowerShell ISE, ou START_HUB.bat si autorisé.
3. Ouvrir UNIQUEMENT : http://localhost:8090/
   Ne plus ouvrir index.html directement avec file://.
4. Test API : http://localhost:8090/api/config
5. A PUBLIER est ignoré.
6. Les fichiers directs sous A TRAITER sont pris en charge (cas CMMABN).
7. Les sous-dossiers sous A TRAITER sont utilisés comme sous-domaines (cas ACM).
