const AGENT=window.CURRENT_AGENT;const API='http://localhost:8080/api';let LIVE_ASSIGNMENTS=[];let selected=null;const key='EPITHETE_TREATMENTS_'+AGENT;who.textContent=AGENT;agentName.textContent=AGENT;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const workKey=x=>[x.agent,x.siret,x.raisonSociale].map(v=>String(v??'').trim().toUpperCase()).join('|');
function history(){try{let a=JSON.parse(localStorage.getItem(key)||'[]'),m=new Map();for(const x of a){let k=workKey(x),old=m.get(k);if(!old||new Date(x.completedAt||0)>new Date(old.completedAt||0))m.set(k,x)}let clean=[...m.values()];if(clean.length!==a.length)localStorage.setItem(key,JSON.stringify(clean));return clean}catch{return []}}
function copyText(v){navigator.clipboard?.writeText(String(v??'')).then(()=>toast('Copié')).catch(()=>{let t=document.createElement('textarea');t.value=String(v??'');document.body.appendChild(t);t.select();document.execCommand('copy');t.remove();toast('Copié')})}
function toast(t){let e=document.getElementById('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1200)}
function row(label,value,copy=true){let v=value??'';return `<div class="info-row"><span>${esc(label)}</span><b>${esc(v||'-')}</b>${copy&&v?`<button class="copy-btn" onclick='copyText(${JSON.stringify(String(v))})'>Copier</button>`:'<i></i>'}</div>`}
function loadAssignments(){
  const seen=new Set();
  const all=LIVE_ASSIGNMENTS;
  const a=all.filter(x=>{
    if(x.agent!==AGENT)return false;
    // Deduplicate only identical active assignment IDs.
    const k=String(x.id||'');
    if(k && seen.has(k))return false;
    if(k)seen.add(k);
    return true;
  });
  count.textContent=a.length;
  list.innerHTML=a.length?a.map(x=>`<div class="assignment" onclick="pick('${x.id}',this)">
    <div class="assignment-top"><b>${esc(x.raisonSociale)}</b><span class="mini-badge">${esc(x.status||'AFFECTEE')}</span></div>
    <div>SIRET : ${esc(x.siret)} · Type : ${esc(x.typeFacture||'-')}</div>
    <div class="muted">Date limite : ${esc(x.dateLimite||'-')}</div>
  </div>`).join(''):'<div class="empty"><b>Tout est à jour</b><span>Aucune affectation active.</span></div>';
}
function pick(id,el){
  selected=LIVE_ASSIGNMENTS.find(x=>x.id===id);
  document.querySelectorAll('.assignment').forEach(x=>x.classList.remove('sel'));el.classList.add('sel');
  let src=selected.source||{};
  sourceInfo.innerHTML=row('Nom CSP',src.nomCSP)+row('Contrat BAD',src.contratBAD)+row('IDT connexion',src.idtConnexion)+row('MDP CSP',src.mdpCSP)+row('N° Abonné CSP',src.numeroAbonneCSP)+row('IBAN prélèvement',src.ibanPrelevement);
  lineInfo.innerHTML=row('Raison sociale',selected.raisonSociale)+row('SIRET',selected.siret)+row('Type facture',selected.typeFacture)+row('Date limite',selected.dateLimite)+row('Commentaire',selected.commentaire,false);
  document.getElementById('selectedTitle').textContent=selected.raisonSociale||'Dossier sélectionné';
  if(selected.status==='A_CORRIGER' && selected.correctionComment){correctionBox.classList.remove('hidden');correctionBox.textContent='Correction demandée : '+selected.correctionComment}else correctionBox.classList.add('hidden');
}
function finish(){
  if(!selected)return alert('Sélectionnez une ligne.');
  let required=[numeroAbonne,idt,mdp,contratBAD,csp];if(required.some(x=>!x.value.trim()))return alert('Complétez les champs de traitement obligatoires.');
  let arr=history(),k=workKey(selected);
  let t={assignmentId:selected.id,agent:AGENT,siret:selected.siret,raisonSociale:selected.raisonSociale,typeFacture:selected.typeFacture,dateLimite:selected.dateLimite,source:selected.source||{},numeroAbonne:numeroAbonne.value.trim(),idt:idt.value.trim(),mdp:mdp.value.trim(),contratBAD:contratBAD.value.trim(),csp:csp.value.trim(),commentaire:commentaire.value.trim(),status:'A_VERIFIER',completedAt:new Date().toISOString()};
  arr=arr.filter(x=>workKey(x)!==k);arr.push(t);localStorage.setItem(key,JSON.stringify(arr));
  let safe=AGENT.replace(/[^A-Za-z0-9_]/g,'_'),text=`window.EPITHETE_CONSOLID_${safe} = ${JSON.stringify({agent:AGENT,generatedAt:new Date().toISOString(),treatments:arr},null,2)};`,blob=new Blob([text],{type:'text/javascript'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=AGENT+'.js';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  selected=null;sourceInfo.innerHTML='<div class="empty compact">Sélectionnez un dossier.</div>';lineInfo.innerHTML='<div class="empty compact">Sélectionnez un dossier.</div>';selectedTitle.textContent='Dossier sélectionné';correctionBox.classList.add('hidden');
  ['numeroAbonne','idt','mdp','contratBAD','csp','commentaire'].forEach(id=>document.getElementById(id).value='');alert('Traitement prêt. Confirmez le remplacement de '+AGENT+'.js dans data\\consolid. La ligne restera visible jusqu’à la synchronisation du serveur.');
}

async function syncFromServer(){
  const syncEl=document.getElementById('syncState');
  try{
    if(syncEl)syncEl.textContent='Synchronisation…';
    const r=await fetch(API+'/assignments?ts='+Date.now(),{cache:'no-store'});
    if(!r.ok)throw new Error('HTTP '+r.status);
    const data=await r.json();
    LIVE_ASSIGNMENTS=Array.isArray(data)?data:(data.assignments||[]);
    loadAssignments();
    if(syncEl){
      const n=LIVE_ASSIGNMENTS.filter(x=>x.agent===AGENT).length;
      syncEl.textContent='Synchronisé · '+n+' ligne'+(n>1?'s':'')+' · '+new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
      syncEl.classList.remove('sync-error');
    }
  }catch(e){
    // Fallback to shared affectations.js if localhost backend is unavailable.
    LIVE_ASSIGNMENTS=(window.AFFECTATIONS?.assignments||[]);
    loadAssignments();
    if(syncEl){
      const n=LIVE_ASSIGNMENTS.filter(x=>x.agent===AGENT).length;
      syncEl.textContent='Mode fichier partagé · '+n+' ligne'+(n>1?'s':'');
      syncEl.classList.add('sync-error');
    }
  }
}
syncFromServer();
