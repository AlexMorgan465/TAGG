﻿$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path;$cfg=Get-Content (Join-Path $base 'config.json') -Raw|ConvertFrom-Json
$share=$cfg.sharedRoot;$historyRoot=$cfg.historyRoot;$desktop=[Environment]::GetFolderPath('Desktop');if([string]::IsNullOrWhiteSpace($desktop)){ $desktop=$cfg.desktopRoot };$agent=if($cfg.agent){$cfg.agent}else{$env:USERNAME};$db=Join-Path $base 'data\pilotage.json';if(!(Test-Path $db)){'[]'|Set-Content $db}
function Log{@(Get-Content $db -Raw|ConvertFrom-Json)};function Save($x){@($x)|ConvertTo-Json -Depth 8|Set-Content $db -Encoding UTF8}
function SetField($o,$name,$value){ if($null -eq $o.PSObject.Properties[$name]){$o|Add-Member -NotePropertyName $name -NotePropertyValue $value}else{$o.$name=$value} }
function SN($n){switch -Regex ($n.ToUpper()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function ID($p){$s=[Security.Cryptography.SHA1]::Create();([BitConverter]::ToString($s.ComputeHash([Text.Encoding]::UTF8.GetBytes($p.ToLower())))).Replace('-','')}
function Scan{
    $a = @()
    if(!(Test-Path -LiteralPath $share -PathType Container)){ throw "Racine partagee introuvable : $share" }

    # Recherche recursive des dossiers de statut, quelle que soit la profondeur avant le statut.
    # A PUBLIER n'est PAS un statut : il est ignore avec toute sa branche.
    # Dans un statut, les fichiers peuvent etre directs (sans sous-domaine) ou ranges dans
    # un ou plusieurs sous-dossiers. Le chemin sous le statut devient le sous-domaine.
    $todo = New-Object System.Collections.Queue
    $todo.Enqueue((Get-Item -LiteralPath $share -Force))

    while($todo.Count -gt 0){
        $dir = $todo.Dequeue()
        $children = @()
        try { $children = @(Get-ChildItem -LiteralPath $dir.FullName -Force -ErrorAction Stop) }
        catch { Write-Host "Scan ignore : $($dir.FullName) - $($_.Exception.Message)" -ForegroundColor Yellow; continue }

        foreach($child in $children){
            if(!$child.PSIsContainer){ continue }
            if($child.Name.ToUpper().Trim() -eq 'A PUBLIER'){ continue }

            $st = SN $child.Name
            if($st){
                if($st -eq 'TRAITES'){ continue }

                $statusDir = $child
                $parentPath = $statusDir.Parent.FullName
                $relParent = if($parentPath.Length -ge $share.Length){ $parentPath.Substring($share.Length).TrimStart('\') }else{ '' }
                $parts = @($relParent -split '\\' | Where-Object { $_ })
                $domain = if($parts.Count -gt 0){ $parts[0] }else{ '' }

                $files = @()
                try { $files = @(Get-ChildItem -LiteralPath $statusDir.FullName -File -Recurse -Force -ErrorAction Stop) }
                catch { Write-Host "Statut ignore : $($statusDir.FullName) - $($_.Exception.Message)" -ForegroundColor Yellow; continue }

                foreach($wi in $files){
                    $relativeDir = $wi.DirectoryName.Substring($statusDir.FullName.Length).TrimStart('\')
                    $a += [pscustomobject]@{
                        id        = ID $wi.FullName
                        name      = $wi.Name
                        fullPath  = $wi.FullName
                        status    = $st
                        statusDir = $statusDir.FullName
                        domain    = $domain
                        subdomain = $relativeDir
                    }
                }
                continue
            }

            $todo.Enqueue($child)
        }
    }
    return @($a)
}
function Item($id){@($script:cacheItems)|? id -eq $id|select -First 1};function Peer($x,$n){$p=Join-Path (Split-Path $x.statusDir -Parent) $n;if($x.subdomain){$p=Join-Path $p $x.subdomain};if(!(Test-Path $p)){mkdir $p -Force|Out-Null};$p}
function Move($s,$d){$t=Join-Path $d (Split-Path $s -Leaf);if(Test-Path $t){throw"Destination existe déjà : $t"};Move-Item -LiteralPath $s -Destination $d;$t}
function Body($q){$r=New-Object IO.StreamReader($q.InputStream);$s=$r.ReadToEnd();$r.Close();$s|ConvertFrom-Json}
function Send($r,$o,$code=200){
  try{$j=$o|ConvertTo-Json -Depth 8;$bytes=[Text.Encoding]::UTF8.GetBytes($j);$r.StatusCode=$code;$r.ContentType='application/json; charset=utf-8';$r.Headers['Access-Control-Allow-Origin']='*';$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length)}
  catch{Write-Host ('HTTP response interrompue : '+$_.Exception.Message) -ForegroundColor Yellow}
  finally{try{$r.OutputStream.Close()}catch{};try{$r.Close()}catch{}}
}
function Min($a,$b){[math]::Round(((Get-Date $b)-(Get-Date $a)).TotalMinutes,2)}
function Static($r,$path){
    $rel=$path.TrimStart('/')
    if([string]::IsNullOrWhiteSpace($rel)){ $rel='index.html' }
    $file=Join-Path $base ($rel -replace '/', '\')
    if(!(Test-Path -LiteralPath $file -PathType Leaf)){ return $false }
    $ext=[IO.Path]::GetExtension($file).ToLower()
    $ct=switch($ext){'.html'{'text/html; charset=utf-8'}'.js'{'application/javascript; charset=utf-8'}'.css'{'text/css; charset=utf-8'}default{'application/octet-stream'}}
    $bytes=[IO.File]::ReadAllBytes($file);$r.StatusCode=200;$r.ContentType=$ct;$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();return $true
}
function DesktopEntries{
  if([string]::IsNullOrWhiteSpace($desktop)){ throw 'Chemin du Bureau introuvable.' }
  if(!(Test-Path -LiteralPath $desktop -PathType Container)){ throw ('Bureau introuvable : '+$desktop) }
  $out=@()
  foreach($it in @(Get-ChildItem -LiteralPath $desktop -Force -ErrorAction Stop | Sort-Object @{Expression={$_.PSIsContainer};Descending=$true},Name)){
    $out += [pscustomobject]@{name=$it.Name;isDirectory=[bool]$it.PSIsContainer;lastWrite=$it.LastWriteTime.ToString('o')}
  }
  return @($out)
}
function ReplaceCacheItem($oldId,$newItem){
  $next=@()
  foreach($ci in @($script:cacheItems)){if($ci.id -eq $oldId){$next+=$newItem}else{$next+=$ci}}
  $script:cacheItems=@($next)
}
# V3.1 FAST: cache memoire. Le reseau n'est rescanné que sur demande explicite.
$script:cacheItems=@()
$script:lastSync=$null
function RefreshCache{
  $sw=[Diagnostics.Stopwatch]::StartNew()
  $script:cacheItems=@(Scan)
  $script:lastSync=(Get-Date).ToString('o')
  $sw.Stop()
  Write-Host ("CACHE -> {0} element(s) en {1} ms" -f $script:cacheItems.Count,$sw.ElapsedMilliseconds) -ForegroundColor Cyan
}
Write-Host "Initialisation du cache reseau..." -ForegroundColor DarkCyan
RefreshCache
$h=New-Object Net.HttpListener;$h.Prefixes.Add('http://localhost:8090/');$h.Start();Write-Host "Accessibility Hub OK http://localhost:8090/" -ForegroundColor Green;Write-Host "Ouvrez http://localhost:8090/ dans Chrome ou Edge" -ForegroundColor Cyan
while($h.IsListening){$c=$h.GetContext();$q=$c.Request;$r=$c.Response;try{$r.Headers['Access-Control-Allow-Origin']='*';$r.Headers['Access-Control-Allow-Headers']='Content-Type';if($q.HttpMethod-eq'OPTIONS'){$r.Close();continue};$p=$q.Url.AbsolutePath
if(!$p.StartsWith('/api/')){if(Static $r $p){continue}else{Send $r @{error='Fichier introuvable'} 404;continue}}
if($p-eq'/api/config'){Send $r @{agent=$agent;lastSync=$script:lastSync;desktop=$desktop};continue};if($p-eq'/api/desktop'){Send $r @{items=@(DesktopEntries);desktop=$desktop};continue};if($p-eq'/api/scan'){Send $r @{items=@($script:cacheItems);lastSync=$script:lastSync};continue};if($p-eq'/api/refresh'){RefreshCache;Send $r @{items=@($script:cacheItems);lastSync=$script:lastSync};continue};if($p-eq'/api/history'){Send $r @{items=@(Log|? agent -eq $agent)};continue}
if($p-eq'/api/take'){
  $b=Body $q; Write-Host ('TAKE -> id='+$b.id) -ForegroundColor Cyan
  $x=Item $b.id
  if($null -eq $x){throw 'Document introuvable. Actualisez la liste.'}

  # V3.2 : idempotent. Un double-clic / second appel sur EN_COURS ne provoque plus d'erreur.
  if($x.status -eq 'EN_COURS'){
    $desktopFile=Join-Path $desktop $x.name
    if(!(Test-Path -LiteralPath $desktopFile -PathType Leaf)){
      Copy-Item -LiteralPath $x.fullPath -Destination $desktopFile -ErrorAction Stop
      Write-Host ('COPIE BUREAU -> '+$desktopFile) -ForegroundColor Magenta
    }
    Send $r @{ok=$true;path=$x.fullPath;id=$x.id;status='EN_COURS';desktopPath=$desktopFile;alreadyInProgress=$true};continue
  }
  if($x.status -ne 'A_TRAITER'){throw ('Statut invalide : '+$x.status)}

  $oldPath=[string]$x.fullPath
  $dest=Peer $x 'EN COURS'
  $new=Join-Path $dest (Split-Path $oldPath -Leaf)
  Write-Host ('MOVE -> '+$oldPath+' => '+$new) -ForegroundColor DarkCyan
  if(Test-Path -LiteralPath $new){throw ('Destination existe deja : '+$new)}
  Move-Item -LiteralPath $oldPath -Destination $dest -ErrorAction Stop
  if(!(Test-Path -LiteralPath $new -PathType Leaf)){throw ('Deplacement non verifie : '+$new)}

  # Copie de travail locale. Le MOVE est deja valide : une erreur de copie Bureau
  # est retournee separement sans annuler le statut EN_COURS dans l'interface.
  $desktopFile=Join-Path $desktop $x.name
  $copyOk=$true;$copyError=$null
  try{
    if(!(Test-Path -LiteralPath $desktop -PathType Container)){New-Item -ItemType Directory -Path $desktop -Force|Out-Null}
    if(Test-Path -LiteralPath $desktopFile){Remove-Item -LiteralPath $desktopFile -Force -ErrorAction Stop}
    Copy-Item -LiteralPath $new -Destination $desktopFile -Force -ErrorAction Stop
    if(!(Test-Path -LiteralPath $desktopFile -PathType Leaf)){throw 'Copie non verifiee'}
    Write-Host ('COPIE BUREAU -> '+$desktopFile) -ForegroundColor Magenta
  }catch{
    $copyOk=$false;$copyError=$_.Exception.Message
    Write-Host ('COPIE BUREAU ECHEC -> '+$copyError) -ForegroundColor Yellow
  }

  $oldId=$x.id
  $x.fullPath=$new;$x.status='EN_COURS';$x.statusDir=(Join-Path (Split-Path $x.statusDir -Parent) 'EN COURS');$x.id=ID $new
  ReplaceCacheItem $oldId $x
  $now=(Get-Date).ToString('o');$l=@(Log);$l+=[pscustomobject]@{recordId=[guid]::NewGuid().ToString();name=$x.name;domain=$x.domain;subdomain=$x.subdomain;agent=$agent;dateEnCours=$now;dateFin=$null;dateRetraitement=$null;status='EN_COURS';status2=$null;dmtMinutes=$null;dmt2Minutes=$null;comment=''};Save $l
  Write-Host ('OK EN COURS -> '+$new) -ForegroundColor Green
  Send $r @{ok=$true;path=$new;id=$x.id;status=$x.status;desktopPath=$desktopFile;copyOk=$copyOk;copyError=$copyError};continue
}
if($p-eq'/api/finish'){
  $b=Body $q;$x=Item $b.id
  if(!$x-or$x.status-ne'EN_COURS'){throw'Item invalide'}
  $desktopName=[string]$b.desktopName
  if([string]::IsNullOrWhiteSpace($desktopName)){throw 'Selectionnez un element du Bureau.'}
  if($desktopName.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $desktopName.Contains('..') -or $desktopName.Contains('\\') -or $desktopName.Contains('/')){throw 'Nom Bureau invalide.'}
  $selected=Join-Path $desktop $desktopName
  if(!(Test-Path -LiteralPath $selected)){throw ('Element Bureau introuvable : '+$desktopName)}
  $targetStatus=if($b.status-eq'TRAITES'){'TRAITES'}elseif($b.status-eq'NON_CONFORME'){'NON CONFORME'}else{throw 'Statut final invalide'}
  $destDir=Peer $x $targetStatus
  $leaf=Split-Path $selected -Leaf
  $target=Join-Path $destDir $leaf
  if(Test-Path -LiteralPath $target){throw ('Destination existe deja : '+$target)}

  # On copie d'abord le dossier choisi vers le DP. Le dossier local reste intact tant que la copie n'est pas validee.
  Write-Host ('FINAL COPY -> '+$selected+' => '+$target) -ForegroundColor Cyan
  Copy-Item -LiteralPath $selected -Destination $target -Recurse -Force -ErrorAction Stop
  if(!(Test-Path -LiteralPath $target)){throw 'La copie vers le DP n a pas pu etre verifiee.'}

  # La copie finale est validee : l'ancien element EN COURS n'a plus besoin d'etre archive sur le reseau.
  # L'historique fonctionnel est conserve dans data\pilotage.json.
  if(Test-Path -LiteralPath $x.fullPath){
    Write-Host ('CLEAN EN COURS -> '+$x.fullPath) -ForegroundColor DarkCyan
    Remove-Item -LiteralPath $x.fullPath -Recurse -Force -ErrorAction Stop
  }

  $now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name-and$_.status-eq'EN_COURS'}|select -Last 1
  if(!$rec){throw'Journal EN_COURS introuvable'}
  SetField $rec 'dateFin' $now; SetField $rec 'dmtMinutes' (Min $rec.dateEnCours $now); SetField $rec 'status' $b.status; SetField $rec 'comment' ([string]$b.comment); Save $l

  $script:cacheItems=@($script:cacheItems|Where-Object {$_.id -ne $b.id})
  $finalItem=$null
  if($b.status-eq'NON_CONFORME'){
    $finalItem=[pscustomobject]@{id=ID $target;name=$leaf;fullPath=$target;status='NON_CONFORME';statusDir=(Join-Path (Split-Path $x.statusDir -Parent) 'NON CONFORME');domain=$x.domain;subdomain=$x.subdomain}
    $script:cacheItems+= $finalItem
  }
  Write-Host ('FINALISE LIVE -> '+$b.status+' | '+$x.name) -ForegroundColor Green
  Send $r @{ok=$true;status=$b.status;removedId=$b.id;item=$finalItem;history=$rec;selectedPath=$selected};continue
}
if($p-eq'/api/rework'){
  $b=Body $q;$x=Item $b.id
  if(!$x-or$x.status-ne'NON_CONFORME'){throw'Item invalide'}
  $desktopName=[string]$b.desktopName
  if([string]::IsNullOrWhiteSpace($desktopName)){ $desktopName=[string]$b.desktopFolder }
  if([string]::IsNullOrWhiteSpace($desktopName)){throw 'Selectionnez un element du Bureau.'}
  if($desktopName.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $desktopName.Contains('..') -or $desktopName.Contains('\\') -or $desktopName.Contains('/')){throw 'Nom Bureau invalide.'}
  $selected=Join-Path $desktop $desktopName
  if(!(Test-Path -LiteralPath $selected)){throw ('Element Bureau introuvable : '+$desktopName)}
  $destDir=Peer $x 'TRAITES';$leaf=Split-Path $selected -Leaf;$target=Join-Path $destDir $leaf
  if(Test-Path -LiteralPath $target){throw ('Destination existe deja : '+$target)}
  Write-Host ('REWORK COPY -> '+$selected+' => '+$target) -ForegroundColor Cyan
  Copy-Item -LiteralPath $selected -Destination $target -Recurse -Force -ErrorAction Stop
  if(!(Test-Path -LiteralPath $target)){throw 'La copie vers TRAITES n a pas pu etre verifiee.'}
  if(Test-Path -LiteralPath $x.fullPath){Remove-Item -LiteralPath $x.fullPath -Recurse -Force -ErrorAction Stop}
  $now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name}|select -Last 1
  if($rec){SetField $rec 'dateRetraitement' $now; SetField $rec 'dmt2Minutes' (Min $rec.dateFin $now); SetField $rec 'status2' 'NON_CONFORME -> TRAITES'; SetField $rec 'status' 'TRAITES'; SetField $rec 'comment' ([string]$b.comment); Save $l}
  $script:cacheItems=@($script:cacheItems|Where-Object {$_.id -ne $b.id})
  Write-Host ('REWORK LIVE -> TRAITES | '+$x.name) -ForegroundColor Green
  Send $r @{ok=$true;status='TRAITES';removedId=$b.id;history=$rec;selectedPath=$selected};continue
}
if($p-eq'/api/export-csv'){$csv=@(Log|? agent -eq $agent)|select name,domain,subdomain,status,status2,dateEnCours,dateFin,dateRetraitement,agent,dmtMinutes,dmt2Minutes,comment|ConvertTo-Csv -NoTypeInformation -Delimiter ';';$bb=[Text.Encoding]::UTF8.GetBytes($csv-join"`r`n");$r.ContentType='text/csv';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.OutputStream.Write($bb,0,$bb.Length);$r.Close();continue};Send $r @{error='Route inconnue'} 404}catch{try{Send $r @{error=$_.Exception.Message} 500}catch{};Write-Host $_.Exception.Message -ForegroundColor Red}}