﻿$ErrorActionPreference = "Stop"
$port = 8080
$baseUrl = "http://localhost:$port/"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $root "data"
$consolidDir = Join-Path $dataDir "consolid"
$affFile = Join-Path $dataDir "affectations.js"
$dbFile = Join-Path $dataDir "manager-db.json"
New-Item -ItemType Directory -Force -Path $dataDir,$consolidDir | Out-Null
if (!(Test-Path $dbFile)) { '{"history":[],"validations":{}}' | Set-Content $dbFile -Encoding UTF8 }
if (!(Test-Path $affFile)) { 'window.AFFECTATIONS = { generatedAt: "", assignments: [] };' | Set-Content $affFile -Encoding UTF8 }
function SendJson($res,$obj,[int]$code=200){ $json=$obj|ConvertTo-Json -Depth 30; $b=[Text.Encoding]::UTF8.GetBytes($json); $res.StatusCode=$code; $res.ContentType='application/json; charset=utf-8'; $res.Headers['Access-Control-Allow-Origin']='*'; $res.Headers['Access-Control-Allow-Methods']='GET,POST,OPTIONS'; $res.Headers['Access-Control-Allow-Headers']='Content-Type'; $res.ContentLength64=$b.Length; $res.OutputStream.Write($b,0,$b.Length); $res.Close() }
function Body($req){ $r=New-Object IO.StreamReader($req.InputStream,$req.ContentEncoding); $s=$r.ReadToEnd();$r.Close(); if($s){$s|ConvertFrom-Json}else{$null} }
function ReadAssignments { $s=Get-Content $affFile -Raw -Encoding UTF8; $s=$s -replace '^\s*window\.AFFECTATIONS\s*=\s*','' -replace ';\s*$',''; if([string]::IsNullOrWhiteSpace($s)){return @()} ; $o=$s|ConvertFrom-Json; return @($o.assignments) }
function WriteAssignments($a){ $o=[ordered]@{generatedAt=(Get-Date).ToString('s');assignments=@($a)}; ('window.AFFECTATIONS = '+($o|ConvertTo-Json -Depth 30)+';')|Set-Content $affFile -Encoding UTF8 }
function ReadConsolid {
  $all=@(); Get-ChildItem $consolidDir -Filter '*.js' -ErrorAction SilentlyContinue | ForEach-Object {
    try { $s=Get-Content $_.FullName -Raw -Encoding UTF8; $s=$s -replace '^\s*window\.CONSOLID_[A-Za-z0-9_]+\s*=\s*','' -replace ';\s*$',''; $o=$s|ConvertFrom-Json; if($o.treatments){$all+=@($o.treatments)} } catch {}
  }; return $all
}
function SyncCompleted {
  $a=ReadAssignments; $t=ReadConsolid; $ids=@{}; foreach($x in $t){ if($x.assignmentId){$ids[$x.assignmentId]=$true} }; $new=@($a|Where-Object{-not $ids.ContainsKey($_.id)}); if($new.Count -ne $a.Count){WriteAssignments $new}; return @{assignments=$new;treatments=$t}
}
$listener=New-Object Net.HttpListener; $listener.Prefixes.Add($baseUrl)
try{$listener.Start()}catch{Write-Host "ERREUR: $($_.Exception.Message)" -ForegroundColor Red; Read-Host 'Entree'; exit}
Write-Host "PeopleList backend OK - $baseUrl" -ForegroundColor Green
Write-Host "Dossier: $root"; Write-Host "Laisser cette fenetre ouverte." -ForegroundColor Yellow
while($listener.IsListening){
 try{$c=$listener.GetContext();$q=$c.Request;$r=$c.Response;if($q.HttpMethod -eq 'OPTIONS'){$r.StatusCode=204;$r.Headers['Access-Control-Allow-Origin']='*';$r.Headers['Access-Control-Allow-Methods']='GET,POST,OPTIONS';$r.Headers['Access-Control-Allow-Headers']='Content-Type';$r.Close();continue};$p=$q.Url.AbsolutePath.TrimEnd('/')
 if($p -eq '/api/test'){SendJson $r @{success=$true;message='Backend PowerShell operationnel'};continue}
 if($p -eq '/api/assignments' -and $q.HttpMethod -eq 'GET'){ $s=SyncCompleted; SendJson $r $s.assignments;continue }
 if($p -eq '/api/assignments' -and $q.HttpMethod -eq 'POST'){ $b=Body $q; $a=@(ReadAssignments); foreach($x in @($b.assignments)){ if(-not $x.id){$x|Add-Member -NotePropertyName id -NotePropertyValue ([guid]::NewGuid().ToString()) -Force}; if(-not $x.status){$x|Add-Member -NotePropertyName status -NotePropertyValue 'AFFECTEE' -Force}; $x|Add-Member -NotePropertyName assignedAt -NotePropertyValue (Get-Date).ToString('s') -Force; $exists=@($a | Where-Object { $_.id -eq $x.id }).Count -gt 0; if(-not $exists){$a=@($a)+@($x)} }; WriteAssignments $a; SendJson $r @{success=$true;count=@($a).Count};continue }
 if($p -eq '/api/treatments' -and $q.HttpMethod -eq 'GET'){ $s=SyncCompleted; $db=Get-Content $dbFile -Raw|ConvertFrom-Json; foreach($x in $s.treatments){$st=$db.validations.($x.assignmentId); if($st){$x.status=$st}}; SendJson $r $s.treatments;continue }
 if($p -eq '/api/status' -and $q.HttpMethod -eq 'POST'){ $b=Body $q; $db=Get-Content $dbFile -Raw|ConvertFrom-Json; if(-not $db.validations){$db|Add-Member validations ([pscustomobject]@{})}; $db.validations|Add-Member -NotePropertyName $b.assignmentId -NotePropertyValue $b.status -Force; $db|ConvertTo-Json -Depth 30|Set-Content $dbFile -Encoding UTF8; if($b.status -eq 'A_CORRIGER'){ $a=ReadAssignments; if(-not (@($a).id -contains $b.assignmentId)){ $t=(ReadConsolid|Where-Object assignmentId -eq $b.assignmentId|Select-Object -First 1); if($t){$a+= [pscustomobject]@{id=$t.assignmentId;agent=$t.agent;siret=$t.siret;raisonSociale=$t.raisonSociale;typeFacture=$t.typeFacture;dateLimite=$t.dateLimite;commentaire=('CORRECTION MANAGER : '+$b.comment);status='A_CORRIGER';assignedAt=(Get-Date).ToString('s')}}; WriteAssignments $a } }; SendJson $r @{success=$true};continue }
 SendJson $r @{success=$false;message='Route introuvable'} 404
 }catch{try{SendJson $r @{success=$false;message=$_.Exception.Message} 500}catch{}}
}
