ACCESSIBILITY HUB V1
1) Modifier config.json avec les 3 chemins réels.
2) Lancer server.ps1.
3) Ouvrir index.html.

DMT = Date_FIN - dateEnCours.
dateEnCours est enregistrée exactement au déplacement A TRAITER -> EN COURS.
DMT2 = Date_Retraitement - Date_FIN du premier passage NON CONFORME.

Le scan est récursif : aucune profondeur fixe n'est imposée.
Aucun écrasement silencieux des destinations.
