ÉPITHÈTE — FULL WORKING BASE

1. Keep this folder together.
2. Run server.ps1 in PowerShell ISE (F5).
3. Open manager.html.
4. Manager writes cumulative assignments to data\affectations.js.
5. Agent pages read data\affectations.js directly (NO fetch / NO localhost in agent.js).
6. Agent finishes a treatment and exports AGENT.js.
7. Save/replace that file in data\consolid\.
8. Manager refreshes Treatments received.

IMPORTANT:
- HAMMDANMO/YASSINE/SARA agent flow is based on the user-confirmed working agent.js.
- Do not replace data\affectations.js when moving UI files into an existing live folder.
