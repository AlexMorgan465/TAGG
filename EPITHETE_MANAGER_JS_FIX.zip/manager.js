const API='http://localhost:8080/api';let drafts=[];let cacheAssignments=[],cacheTreatments=[];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot',"'":'&#39;'}[c]));
const keyOf=x=>[x.agent,x.siret,x.raisonSociale].map(v=>String(v??'').trim().toUpperCase()).join('|');
function show(id,b){document.querySelectorAll('main section').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active'));b?.classList.add('active');if(id==='dash')setTimeout(drawCharts,30)}
async function test(){try{let r=await fetch(API+'/test');if(!r.ok)throw 0;backend.innerHTML='<i></i> Backend connecté';backend.classList.add('online')}catch{backend.textContent='● Backend inaccessible'}}
function addDraft(o={}){let x={id:crypto.randomUUID(),siret:o.siret??siret.value,raisonSociale:o.raisonSociale??raison.value,typeFacture:o.typeFacture??type.value,dateLimite:o.dateLimite??date.value,commentaire:o.commentaire??comment.value,source:o.source||{},agent:o.agent??agent.value,status:'AFFECTEE'};if(drafts.some(d=>keyOf(d)===keyOf(x)))return;drafts.push(x);renderDrafts()}
function renderDrafts(){draftRows.innerHTML=drafts.map((x,i)=>`<tr><td>${esc(x.siret)}</td><td><b>${esc(x.raisonSociale)}</b></td><td>${esc(x.typeFacture)}</td><td>${esc(x.dateLimite)}</td><td><select onchange="drafts[${i}].agent=this.value"><option ${x.agent==='HAMDANMO'?'selected':''}>HAMDANMO</option><option ${x.agent==='YASSINE'?'selected':''}>YASSINE</option><option ${x.agent==='SARA'?'selected':''}>SARA</option></select></td><td><button class="icon-btn" onclick="drafts.splice(${i},1);renderDrafts()">×</button></td></tr>`).join('');draftCount.textContent=drafts.length}
async function sendAssignments(){if(!drafts.length)return alert('Aucune ligne.');try{let r=await fetch(API+'/assignments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({assignments:drafts})}),data=await r.json();if(!r.ok)throw new Error(data?.message||('HTTP '+r.status));drafts=[];renderDrafts();await loadAssignments();alert(`${data.added} affectation(s) ajoutée(s). ${data.duplicatesRemoved||0} doublon(s) ignoré(s). Total actif : ${data.count}`)}catch(e){alert('Erreur serveur : '+e.message)}}
async function loadAssignments(){try{cacheAssignments=await (await fetch(API+'/assignments?x='+Date.now())).json();activeRows.innerHTML=cacheAssignments.length?cacheAssignments.map(x=>`<tr><td><span class="avatar">${esc(x.agent).slice(0,2)}</span>${esc(x.agent)}</td><td>${esc(x.siret)}</td><td><b>${esc(x.raisonSociale)}</b></td><td><span class="badge">${esc(x.status)}</span></td></tr>`).join(''):'<tr><td colspan="4" class="table-empty">Aucune affectation active</td></tr>';updateKPIs()}catch{}}
async function loadTreatments(){
 try{
  const res=await fetch(API+'/treatments?x='+Date.now(),{cache:'no-store'});
  if(!res.ok)throw new Error('HTTP '+res.status);
  const raw=await res.json();
  const list=Array.isArray(raw)?raw:(Array.isArray(raw.treatments)?raw.treatments:[]);
  const map=new Map();

  for(const x of list){
   const fallback=[x.agent,x.siret,x.raisonSociale].map(v=>String(v??'').trim().toUpperCase()).join('|');
   const k=x.assignmentId?('ID|'+String(x.assignmentId)):('WK|'+fallback);
   const previous=map.get(k);
   if(!previous || new Date(x.completedAt||0)>=new Date(previous.completedAt||0))map.set(k,x);
  }

  cacheTreatments=[...map.values()].sort((a,b)=>new Date(b.completedAt||0)-new Date(a.completedAt||0));

  const tbody=document.getElementById('treatRows');
  if(tbody){
   tbody.innerHTML=cacheTreatments.length?cacheTreatments.map(x=>`
    <tr>
     <td><span class="avatar">${esc(x.agent||'').slice(0,2)}</span>${esc(x.agent||'-')}</td>
     <td><b>${esc(x.raisonSociale||'-')}</b><div class="muted">${esc(x.siret||'-')}</div></td>
     <td>${esc(x.typeFacture||'-')}</td>
     <td>${esc(x.numeroAbonne||'-')}</td>
     <td>${esc(x.idt||'-')}</td>
     <td>${esc(x.contratBAD||'-')}</td>
     <td>${esc(x.csp||'-')}</td>
     <td><span class="badge ${x.status==='VALIDEE'?'valid':x.status==='A_CORRIGER'?'correction':''}">${esc(x.status||'A_VERIFIER')}</span><div class="muted">${x.completedAt?new Date(x.completedAt).toLocaleString('fr-FR'):'-'}</div></td>
     <td class="actions"><button class="ok small" onclick="statusChange('${String(x.assignmentId||'').replace(/'/g,"\\'")}','VALIDEE')">Valider</button><button class="warn small" onclick="correct('${String(x.assignmentId||'').replace(/'/g,"\\'")}')">Corriger</button></td>
    </tr>`).join(''):'<tr><td colspan="9" class="table-empty">Aucun traitement reçu depuis data\\consolid</td></tr>';
  }

  renderManagerHistory();
  updateKPIs();
 }catch(e){
  console.error('loadTreatments',e);
  const tbody=document.getElementById('treatRows');
  if(tbody)tbody.innerHTML=`<tr><td colspan="9" class="table-empty">Erreur de lecture Manager : ${esc(e.message)}</td></tr>`;
 }
}
function renderManagerHistory(){
 let el=document.getElementById('managerHistory');if(!el)return;
 let rows=[...cacheTreatments].sort((a,b)=>new Date(b.completedAt||0)-new Date(a.completedAt||0));
 el.innerHTML=rows.length?rows.map(x=>`<article class="manager-history-card"><div class="mh-head"><div><span class="avatar">${esc(x.agent).slice(0,2)}</span><b>${esc(x.raisonSociale)}</b><small>${esc(x.agent)} · ${esc(x.siret)}</small></div><span class="badge ${x.status==='VALIDEE'?'valid':x.status==='A_CORRIGER'?'correction':''}">${esc(x.status||'A_VERIFIER')}</span></div><div class="mh-grid"><span>Type<b>${esc(x.typeFacture||'-')}</b></span><span>N° Abonné<b>${esc(x.numeroAbonne||'-')}</b></span><span>IDT<b>${esc(x.idt||'-')}</b></span><span>Contrat BAD<b>${esc(x.contratBAD||'-')}</b></span><span>CSP<b>${esc(x.csp||'-')}</b></span><span>Date limite<b>${esc(x.dateLimite||'-')}</b></span></div><div class="mh-foot"><span>${x.completedAt?new Date(x.completedAt).toLocaleString('fr-FR'):'-'}</span>${x.commentaire?`<span>Commentaire : ${esc(x.commentaire)}</span>`:''}</div></article>`).join(''):'<div class="table-empty">Aucun historique consolidé.</div>';
}
async function consolidDiagnostic(){
 try{let d=await (await fetch(API+'/consolid-status?x='+Date.now())).json();alert(`Dossier lu par le serveur :\\n${d.folder}\\n\\nFichiers JS détectés : ${d.fileCount}\\nTraitements lus : ${d.treatmentCount}\\n\\n${(d.files||[]).join('\\n')}`)}catch(e){alert('Diagnostic impossible : '+e.message)}
}
function updateKPIs(){kActive.textContent=cacheAssignments.length;kReceived.textContent=cacheTreatments.length;kVerify.textContent=cacheTreatments.filter(x=>(x.status||'A_VERIFIER')==='A_VERIFIER').length;kValid.textContent=cacheTreatments.filter(x=>x.status==='VALIDEE').length;drawCharts()}
async function statusChange(id,status,comment=''){await fetch(API+'/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({assignmentId:id,status,comment})});await refreshAll()}
function correct(id){let c=prompt('Commentaire de correction pour l’agent :','');if(c!==null)statusChange(id,'A_CORRIGER',c)}
async function refreshAll(){await loadAssignments();await loadTreatments()}
function drawDonut(canvas,vals,labels){let c=canvas,ctx=c.getContext('2d'),dpr=devicePixelRatio||1,w=c.clientWidth||360,h=c.clientHeight||230;c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);let total=vals.reduce((a,b)=>a+b,0)||1,cx=w*.34,cy=h*.5,r=Math.min(w,h)*.28,start=-Math.PI/2,colors=['#0b8062','#163f58','#d9a441','#dce8e4'];vals.forEach((v,i)=>{let a=v/total*Math.PI*2;ctx.beginPath();ctx.strokeStyle=colors[i];ctx.lineWidth=22;ctx.arc(cx,cy,r,start,start+a);ctx.stroke();start+=a});ctx.fillStyle='#12201d';ctx.font='700 25px Segoe UI';ctx.textAlign='center';ctx.fillText(String(vals.reduce((a,b)=>a+b,0)),cx,cy+7);ctx.textAlign='left';ctx.font='600 12px Segoe UI';labels.forEach((l,i)=>{let y=50+i*35;ctx.fillStyle=colors[i];ctx.fillRect(w*.68,y-9,10,10);ctx.fillStyle='#60716c';ctx.fillText(l+'  '+vals[i],w*.68+18,y)})}
function drawBars(canvas,groups){let c=canvas,ctx=c.getContext('2d'),dpr=devicePixelRatio||1,w=c.clientWidth||500,h=c.clientHeight||230;c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);let max=Math.max(1,...groups.map(x=>x.v)),base=h-35,bw=Math.min(58,(w-70)/Math.max(groups.length,1)*.45);ctx.strokeStyle='#e5ece9';ctx.beginPath();ctx.moveTo(38,18);ctx.lineTo(38,base);ctx.lineTo(w-12,base);ctx.stroke();groups.forEach((g,i)=>{let x=55+i*((w-80)/groups.length),bh=(base-30)*g.v/max;ctx.fillStyle='#0b8062';ctx.fillRect(x,base-bh,bw,bh);ctx.fillStyle='#60716c';ctx.font='600 11px Segoe UI';ctx.fillText(g.n.slice(0,10),x,base+18);ctx.fillStyle='#12201d';ctx.fillText(g.v,x+bw/2-3,base-bh-8)})}
function drawCharts(){if(!document.getElementById('statusChart'))return;let verify=cacheTreatments.filter(x=>(x.status||'A_VERIFIER')==='A_VERIFIER').length,valid=cacheTreatments.filter(x=>x.status==='VALIDEE').length,corr=cacheTreatments.filter(x=>x.status==='A_CORRIGER').length;drawDonut(statusChart,[cacheAssignments.length,verify,valid,corr],['Actives','À vérifier','Validées','Corrections']);let names=[...new Set([...cacheAssignments,...cacheTreatments].map(x=>x.agent))];drawBars(agentChart,names.map(n=>({n,v:cacheTreatments.filter(x=>x.agent===n).length})))}
function exportDashboard(){let rows=cacheTreatments.map(x=>({Agent:x.agent,SIRET:x.siret,'Raison sociale':x.raisonSociale,'N° Abonné':x.numeroAbonne,IDT:x.idt,MDP:x.mdp,'Contrat BAD':x.contratBAD,CSP:x.csp,Commentaire:x.commentaire,Statut:x.status||'A_VERIFIER','Terminé le':x.completedAt}));let wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(rows);XLSX.utils.book_append_sheet(wb,ws,'Traitements');let summary=[['ÉPITHÈTE - Tableau de bord','Valeur'],['Affectations actives',cacheAssignments.length],['Traitements reçus',cacheTreatments.length],['À vérifier',cacheTreatments.filter(x=>(x.status||'A_VERIFIER')==='A_VERIFIER').length],['Validés',cacheTreatments.filter(x=>x.status==='VALIDEE').length],['À corriger',cacheTreatments.filter(x=>x.status==='A_CORRIGER').length]];XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(summary),'Dashboard');XLSX.writeFile(wb,'EPITHETE_TDB_'+new Date().toISOString().slice(0,10)+'.xlsx')}
excel.addEventListener('change',async e=>{
 let f=e.target.files[0];if(!f)return;
 let wb=XLSX.read(await f.arrayBuffer(),{type:'array'}),ws=wb.Sheets[wb.SheetNames[0]],rows=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:true});
 let hi=rows.findIndex(r=>r.some(v=>/siret/i.test(String(v)))&&r.some(v=>/raison/i.test(String(v))));
 if(hi<0)return alert('En-têtes SIRET / Raison sociale non détectés.');
 const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const rightOf=rx=>{for(let r=0;r<hi;r++)for(let c=0;c<(rows[r]||[]).length;c++)if(rx.test(norm(rows[r][c]))){for(let j=c+1;j<(rows[r]||[]).length;j++)if(String(rows[r][j]??'').trim()!=='')return rows[r][j]}return ''};
 let nomCSP='';for(let r=0;r<Math.min(hi,4);r++){let first=(rows[r]||[]).find(v=>String(v??'').trim()!=='');if(first&&!/coordonn|contrat|connexion|mdp|abonne|iban/i.test(norm(first))){nomCSP=first;break}}
 const source={nomCSP:String(nomCSP??'').trim(),contratBAD:String(rightOf(/^contrat\s*(bad|b@d)/i)??'').trim(),idtConnexion:String(rightOf(/^(idt|identifiant).*connexion/i)??'').trim(),mdpCSP:String(rightOf(/^mdp.*csp|mot de passe.*csp/i)??'').trim(),numeroAbonneCSP:String(rightOf(/abonne.*csp|numero.*abonne.*csp/i)??'').trim(),ibanPrelevement:String(rightOf(/^iban.*prelev/i)??'').trim()};
 const excelDate=v=>{if(v===null||v===undefined||v==='')return '';if(typeof v==='number'||/^\d{5}(\.\d+)?$/.test(String(v).trim())){let d=XLSX.SSF.parse_date_code(Number(v));if(d)return String(d.d).padStart(2,'0')+'/'+String(d.m).padStart(2,'0')+'/'+d.y}return String(v).trim()};
 let h=rows[hi].map(v=>String(v).trim()),ix=p=>h.findIndex(v=>p.test(v)),si=ix(/siret/i),ri=ix(/raison/i),ti=ix(/facture|emission|réception|reception/i),di=ix(/date limite/i),ci=ix(/comment/i);
 rows.slice(hi+1).filter(r=>r[si]||r[ri]).forEach(r=>addDraft({siret:r[si],raisonSociale:r[ri],typeFacture:ti>=0?r[ti]:'',dateLimite:di>=0?excelDate(r[di]):'',commentaire:ci>=0?r[ci]:'',source:{...source},agent:'HAMDANMO'}));
});
test();refreshAll();
