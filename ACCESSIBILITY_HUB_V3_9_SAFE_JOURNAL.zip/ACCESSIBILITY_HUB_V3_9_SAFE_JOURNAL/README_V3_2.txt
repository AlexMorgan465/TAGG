ACCESSIBILITY HUB V3.2 DESKTOP

- Prendre en charge : A TRAITER -> EN COURS
- Une copie du PDF est automatiquement creee sur le Bureau
- Double-clic / second appel EN COURS est idempotent
- L agent travaille uniquement sur la copie du Bureau
- Finaliser : la copie Bureau est envoyee vers TRAITES ou NON CONFORME
- L original EN COURS est archive automatiquement
- Cache FAST et filtres V3.1 conserves
