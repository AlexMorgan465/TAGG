ACCESSIBILITY HUB V3.1 FAST

- Cache memoire PowerShell au demarrage.
- /api/scan ne rescane plus le partage reseau.
- Actualiser est la seule action qui force une synchronisation reseau.
- Filtres/recherche 100% navigateur.
- Prendre en charge met a jour l'interface et le cache sans rescan complet.
- Indicateur 'Synchronise a HH:MM:SS'.

IMPORTANT: fermez l'ancien serveur avant de lancer START_HUB.bat.
Le premier demarrage peut prendre le temps du scan initial; ensuite l'interface et les actions sont instantanees.
