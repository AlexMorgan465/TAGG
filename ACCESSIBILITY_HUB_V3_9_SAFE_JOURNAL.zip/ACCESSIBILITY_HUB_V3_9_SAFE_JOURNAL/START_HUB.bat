﻿@echo off
cd /d "%~dp0"
start "" http://localhost:8090/
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
