ACCESSIBILITY HUB V3 FUTURE
1. Copiez votre config.json réel dans ce dossier si nécessaire.
2. Fermez l'ancien serveur sur le port 8090.
3. Lancez START_HUB.bat ou server.ps1.
4. Ouvrez http://localhost:8090/

Nouveautés : interface futuriste accessible, filtres Domaine/Sous-domaine/Statut,
Actualiser avec retour visuel, prise en charge avec message d'erreur visible,
journal PowerShell TAKE/MOVE/OK pour diagnostic immédiat.
