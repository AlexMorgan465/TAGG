ACCESSIBILITY HUB V3.3 LIVE
- Prendre en charge : A TRAITER -> EN COURS + copie de travail sur le vrai Bureau Windows.
- Mise a jour LIVE du cache et de l'interface, sans resynchronisation reseau.
- Finaliser : ouvre une fenetre Windows pour choisir le dossier traite.
- Le dossier choisi est copie vers TRAITES ou NON CONFORME; le dossier local n'est pas supprime automatiquement.
- Actualiser reste reserve aux changements effectues hors de l'application.
