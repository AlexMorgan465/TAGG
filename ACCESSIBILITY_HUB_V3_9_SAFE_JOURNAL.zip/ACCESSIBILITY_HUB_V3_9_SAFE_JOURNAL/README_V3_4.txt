ACCESSIBILITY HUB V3.4 LIVE FRONTEND

- Etat du document mis a jour immediatement dans JavaScript apres clic (optimistic UI).
- Aucun rescan DP pour A TRAITER -> EN COURS ou finalisation.
- Correction de la copie Bureau: le chemin EN COURS est calcule explicitement et verifie avant Copy-Item.
- Une erreur de copie Bureau ne masque plus un MOVE DP deja reussi.
- Suppression du FolderBrowserDialog PowerShell bloquant.
- Le bouton Traiter ouvre maintenant un modal HTML rapide listant le Bureau.
- Le backend ne fait le travail filesystem qu'apres confirmation.
- Actualiser reste une reconciliation explicite avec le DP.
