ACCESSIBILITY HUB V3.5 - NO NETWORK HISTORY

- Suppression de la dependance au dossier historyRoot pour terminer un traitement.
- Apres copie verifiee vers TRAITES ou NON CONFORME, l ancien element EN COURS est supprime.
- L historique applicatif reste dans data\pilotage.json.
- Le dossier/fichier local selectionne reste sur le Bureau.
- Le cache frontend/backend est mis a jour sans resynchronisation.
- Retraitement NON CONFORME -> TRAITES suit la meme logique, sans archive reseau.

IMPORTANT: conserver votre config.json reel pour sharedRoot/desktopRoot. historyRoot n est plus utilise pour les operations de finalisation.
