ACCESSIBILITY HUB V3.7 - HISTORIQUE + STATS LIVE

- Historique tableau: Nom fichier, Domaine, Sous-domaine, Statut, Statut 2, Date prise en charge, Date FIN, Date retraitement, Agent, DMT, DMT2, Commentaire.
- Date FIN = clic de confirmation TRAITE / NON CONFORME.
- DMT affiche en HH:MM:SS.
- Statistiques recalculees instantanement depuis le journal local, sans rescan DP.
- Compatibilite avec anciens enregistrements pilotage.json via SetField.
- Retraitement met aussi historique/statistiques a jour sans load()/resynchronisation.
