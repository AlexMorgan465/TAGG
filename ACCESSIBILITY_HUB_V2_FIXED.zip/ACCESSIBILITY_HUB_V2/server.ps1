﻿$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path;$cfg=Get-Content (Join-Path $base 'config.json') -Raw|ConvertFrom-Json
$share=$cfg.sharedRoot;$historyRoot=$cfg.historyRoot;$desktop=$cfg.desktopRoot;$agent=if($cfg.agent){$cfg.agent}else{$env:USERNAME};$db=Join-Path $base 'data\pilotage.json';if(!(Test-Path $db)){'[]'|Set-Content $db}
function Log{@(Get-Content $db -Raw|ConvertFrom-Json)};function Save($x){@($x)|ConvertTo-Json -Depth 8|Set-Content $db -Encoding UTF8}
function SN($n){switch -Regex ($n.ToUpper()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function ID($p){$s=[Security.Cryptography.SHA1]::Create();([BitConverter]::ToString($s.ComputeHash([Text.Encoding]::UTF8.GetBytes($p.ToLower())))).Replace('-','')}
function Scan{
    $a = @()
    if(!(Test-Path -LiteralPath $share -PathType Container)){ throw "Racine partagee introuvable : $share" }

    # Recherche recursive des dossiers de statut, quelle que soit la profondeur avant le statut.
    # A PUBLIER n'est PAS un statut : il est ignore avec toute sa branche.
    # Dans un statut, les fichiers peuvent etre directs (sans sous-domaine) ou ranges dans
    # un ou plusieurs sous-dossiers. Le chemin sous le statut devient le sous-domaine.
    $todo = New-Object System.Collections.Queue
    $todo.Enqueue((Get-Item -LiteralPath $share -Force))

    while($todo.Count -gt 0){
        $dir = $todo.Dequeue()
        $children = @()
        try { $children = @(Get-ChildItem -LiteralPath $dir.FullName -Force -ErrorAction Stop) }
        catch { Write-Host "Scan ignore : $($dir.FullName) - $($_.Exception.Message)" -ForegroundColor Yellow; continue }

        foreach($child in $children){
            if(!$child.PSIsContainer){ continue }
            if($child.Name.ToUpper().Trim() -eq 'A PUBLIER'){ continue }

            $st = SN $child.Name
            if($st){
                if($st -eq 'TRAITES'){ continue }

                $statusDir = $child
                $parentPath = $statusDir.Parent.FullName
                $relParent = if($parentPath.Length -ge $share.Length){ $parentPath.Substring($share.Length).TrimStart('\') }else{ '' }
                $parts = @($relParent -split '\\' | Where-Object { $_ })
                $domain = if($parts.Count -gt 0){ $parts[0] }else{ '' }

                $files = @()
                try { $files = @(Get-ChildItem -LiteralPath $statusDir.FullName -File -Recurse -Force -ErrorAction Stop) }
                catch { Write-Host "Statut ignore : $($statusDir.FullName) - $($_.Exception.Message)" -ForegroundColor Yellow; continue }

                foreach($wi in $files){
                    $relativeDir = $wi.DirectoryName.Substring($statusDir.FullName.Length).TrimStart('\')
                    $a += [pscustomobject]@{
                        id        = ID $wi.FullName
                        name      = $wi.Name
                        fullPath  = $wi.FullName
                        status    = $st
                        statusDir = $statusDir.FullName
                        domain    = $domain
                        subdomain = $relativeDir
                    }
                }
                continue
            }

            $todo.Enqueue($child)
        }
    }
    ,@($a)
}
function Item($id){Scan|? id -eq $id|select -First 1};function Peer($x,$n){$p=Join-Path (Split-Path $x.statusDir -Parent) $n;if($x.subdomain){$p=Join-Path $p $x.subdomain};if(!(Test-Path $p)){mkdir $p -Force|Out-Null};$p}
function Move($s,$d){$t=Join-Path $d (Split-Path $s -Leaf);if(Test-Path $t){throw"Destination existe déjà : $t"};Move-Item -LiteralPath $s -Destination $d;$t}
function Body($q){$r=New-Object IO.StreamReader($q.InputStream);$s=$r.ReadToEnd();$r.Close();$s|ConvertFrom-Json}
function Send($r,$o,$code=200){$j=$o|ConvertTo-Json -Depth 8;$b=[Text.Encoding]::UTF8.GetBytes($j);$r.StatusCode=$code;$r.ContentType='application/json; charset=utf-8';$r.ContentLength64=$b.Length;$r.Headers['Access-Control-Allow-Origin']='*';$r.OutputStream.Write($b,0,$b.Length);$r.OutputStream.Close()}
function Min($a,$b){[math]::Round(((Get-Date $b)-(Get-Date $a)).TotalMinutes,2)}
function Static($r,$path){
    $rel=$path.TrimStart('/')
    if([string]::IsNullOrWhiteSpace($rel)){ $rel='index.html' }
    $file=Join-Path $base ($rel -replace '/', '\')
    if(!(Test-Path -LiteralPath $file -PathType Leaf)){ return $false }
    $ext=[IO.Path]::GetExtension($file).ToLower()
    $ct=switch($ext){'.html'{'text/html; charset=utf-8'}'.js'{'application/javascript; charset=utf-8'}'.css'{'text/css; charset=utf-8'}default{'application/octet-stream'}}
    $bytes=[IO.File]::ReadAllBytes($file);$r.StatusCode=200;$r.ContentType=$ct;$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();return $true
}
$h=New-Object Net.HttpListener;$h.Prefixes.Add('http://localhost:8090/');$h.Start();Write-Host "Accessibility Hub OK http://localhost:8090/" -ForegroundColor Green;Write-Host "Ouvrez http://localhost:8090/ dans Chrome ou Edge" -ForegroundColor Cyan
while($h.IsListening){$c=$h.GetContext();$q=$c.Request;$r=$c.Response;try{$r.Headers['Access-Control-Allow-Origin']='*';$r.Headers['Access-Control-Allow-Headers']='Content-Type';if($q.HttpMethod-eq'OPTIONS'){$r.Close();continue};$p=$q.Url.AbsolutePath
if(!$p.StartsWith('/api/')){if(Static $r $p){continue}else{Send $r @{error='Fichier introuvable'} 404;continue}}
if($p-eq'/api/config'){Send $r @{agent=$agent};continue};if($p-eq'/api/scan'){Send $r @{items=@(Scan)};continue};if($p-eq'/api/history'){Send $r @{items=@(Log|? agent -eq $agent)};continue}
if($p-eq'/api/take'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'A_TRAITER'){throw'Item invalide'};$new=Move $x.fullPath (Peer $x 'EN COURS');$now=(Get-Date).ToString('o');$l=@(Log);$l+=[pscustomobject]@{recordId=[guid]::NewGuid().ToString();name=$x.name;domain=$x.domain;subdomain=$x.subdomain;agent=$agent;dateEnCours=$now;dateFin=$null;dateRetraitement=$null;status='EN_COURS';status2=$null;dmtMinutes=$null;dmt2Minutes=$null;comment=''};Save $l;Send $r @{ok=$true};continue}
if($p-eq'/api/finish'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'EN_COURS'){throw'Item invalide'};$folder=Join-Path $desktop $b.desktopFolder;if(!(Test-Path $folder -PathType Container)){throw"Dossier Bureau introuvable"};$expected=[IO.Path]::GetFileNameWithoutExtension($x.name);if((Split-Path $folder -Leaf)-notin @($expected,$x.name)){throw"Le dossier Bureau doit avoir le nom : $expected"};$dest=if($b.status-eq'TRAITES'){'TRAITES'}else{'NON CONFORME'};Move $folder (Peer $x $dest)|Out-Null;$hd=Join-Path $historyRoot $x.domain;mkdir $hd -Force|Out-Null;Move $x.fullPath $hd|Out-Null;$now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name-and$_.status-eq'EN_COURS'}|select -Last 1;if(!$rec){throw'Journal EN_COURS introuvable'};$rec.dateFin=$now;$rec.dmtMinutes=Min $rec.dateEnCours $now;$rec.status=$b.status;$rec.comment=$b.comment;Save $l;Send $r @{ok=$true};continue}
if($p-eq'/api/rework'){$b=Body $q;$x=Item $b.id;if(!$x-or$x.status-ne'NON_CONFORME'){throw'Item invalide'};$folder=Join-Path $desktop $b.desktopFolder;if(!(Test-Path $folder -PathType Container)){throw'Dossier Bureau introuvable'};Move $folder (Peer $x 'TRAITES')|Out-Null;$arc=Join-Path $historyRoot 'NON_CONFORME_ARCHIVE';mkdir $arc -Force|Out-Null;Move $x.fullPath $arc|Out-Null;$now=(Get-Date).ToString('o');$l=@(Log);$rec=$l|?{$_.agent-eq$agent-and$_.name-eq$x.name}|select -Last 1;$rec.dateRetraitement=$now;$rec.dmt2Minutes=Min $rec.dateFin $now;$rec.status2='NON_CONFORME -> TRAITES';$rec.status='TRAITES';Save $l;Send $r @{ok=$true};continue}
if($p-eq'/api/export-csv'){$csv=@(Log|? agent -eq $agent)|select name,domain,subdomain,status,status2,dateEnCours,dateFin,dateRetraitement,agent,dmtMinutes,dmt2Minutes,comment|ConvertTo-Csv -NoTypeInformation -Delimiter ';';$bb=[Text.Encoding]::UTF8.GetBytes($csv-join"`r`n");$r.ContentType='text/csv';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.OutputStream.Write($bb,0,$bb.Length);$r.Close();continue};Send $r @{error='Route inconnue'} 404}catch{try{Send $r @{error=$_.Exception.Message} 500}catch{};Write-Host $_.Exception.Message -ForegroundColor Red}}