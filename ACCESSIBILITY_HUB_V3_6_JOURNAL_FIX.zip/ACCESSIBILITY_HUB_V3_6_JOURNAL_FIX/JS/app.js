const API='/api';let data=[],hist=[],sel=null;const $=x=>document.getElementById(x),e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg,bad=false){const t=$('toast');t.textContent=msg;t.className=bad?'show bad':'show';clearTimeout(window._tt);window._tt=setTimeout(()=>t.className='',3500)}
function syncLabel(v){const el=$('lastSync');if(!el)return;if(!v){el.textContent='Cache prêt';return}const d=new Date(v);el.textContent='Synchronisé à '+d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}
async function req(p,o={}){const r=await fetch(API+p,{cache:'no-store',headers:{'Content-Type':'application/json'},...o});let j={};try{j=await r.json()}catch{}if(!r.ok)throw Error(j.error||`Erreur HTTP ${r.status}`);return j}
async function load(manual=false){const b=$('refreshBtn');if(b&&manual){b.disabled=true;b.textContent='↻ Synchronisation…'}try{const scanPath=manual?'/refresh':'/scan';const [c,s,h]=await Promise.all([req('/config'),req(scanPath),req('/history')]);$('state').textContent='● Backend connecté';$('state').className='online';$('hello').textContent=$('agent').textContent=c.agent;$('avatar').textContent=(c.agent||'A')[0].toUpperCase();data=Array.isArray(s.items)?s.items:[];hist=Array.isArray(h.items)?h.items:[];fillFilters();render();historyView();stats();syncLabel(s.lastSync||c.lastSync);if(manual)toast(`${data.length} élément(s) synchronisé(s)`)}catch(x){$('state').textContent='● Backend indisponible';$('state').className='offline';toast(x.message,true);console.error(x)}finally{if(b&&manual){b.disabled=false;b.textContent='↻ Actualiser'}}}
function badge(s){const label={A_TRAITER:'À TRAITER',EN_COURS:'EN COURS',NON_CONFORME:'NON CONFORME',TRAITES:'TRAITÉ'}[s]||s;return `<span class="badge ${s}">${label}</span>`}
function fillFilters(){const df=$('domainFilter'),sf=$('subdomainFilter'),dv=df.value,sv=sf.value;const domains=[...new Set(data.map(x=>x.domain).filter(Boolean))].sort();df.innerHTML='<option value="">Tous les domaines</option>'+domains.map(v=>`<option>${e(v)}</option>`).join('');if(domains.includes(dv))df.value=dv;const subs=[...new Set(data.filter(x=>!df.value||x.domain===df.value).map(x=>x.subdomain).filter(Boolean))].sort();sf.innerHTML='<option value="">Tous les sous-domaines</option>'+subs.map(v=>`<option>${e(v)}</option>`).join('');if(subs.includes(sv))sf.value=sv}
function filtered(){const q=$('q').value.trim().toLowerCase(),d=$('domainFilter').value,sd=$('subdomainFilter').value,st=$('statusFilter').value;return data.filter(x=>['A_TRAITER','EN_COURS'].includes(x.status)&&(!d||x.domain===d)&&(!sd||x.subdomain===sd)&&(!st||x.status===st)&&(`${x.name} ${x.domain} ${x.subdomain}`).toLowerCase().includes(q))}
function render(){const a=filtered();$('resultCount').textContent=`(${a.length} résultat${a.length>1?'s':''})`;$('list').innerHTML=a.map(x=>`<div class="trow" onclick="pick('${x.id}')"><span class="filename">▣ <b>${e(x.name)}</b></span><span>${e(x.domain||'—')}</span><span>${e(x.subdomain||'—')}</span><span>${badge(x.status)}</span><span>${x.status==='A_TRAITER'?`<button class="mini" onclick="event.stopPropagation();take('${x.id}',this)">Prendre en charge</button>`:'<button class="mini secondary" onclick="event.stopPropagation();pick(\''+x.id+'\')">Finaliser</button>'}</span></div>`).join('')||'<div class="empty">Aucun document avec ces filtres.</div>';$('nclist').innerHTML=data.filter(x=>x.status==='NON_CONFORME').map(x=>`<div class="nrow" onclick="nc('${x.id}')"><b>${e(x.name)}</b><span>${e(x.domain)} · ${e(x.subdomain||'—')}</span>${badge(x.status)}</div>`).join('')||'<div class="empty">Aucun non conforme.</div>';$('todo').textContent=data.filter(x=>x.status==='A_TRAITER').length;$('doing').textContent=data.filter(x=>x.status==='EN_COURS').length;$('nck').textContent=data.filter(x=>x.status==='NON_CONFORME').length;$('done').textContent=hist.filter(x=>x.status==='TRAITES').length}
function pick(id){sel=data.find(x=>x.id===id);if(!sel)return;const x=sel;$('detail').innerHTML=`<div class="detailhead"><div class="fileicon">▤</div><div><h3>${e(x.name)}</h3>${badge(x.status)}</div></div><dl><dt>Domaine</dt><dd>${e(x.domain||'—')}</dd><dt>Sous-domaine</dt><dd>${e(x.subdomain||'—')}</dd></dl><div class="actions">${x.status==='A_TRAITER'?`<button class="glow big" onclick="take('${x.id}',this)">Prendre en charge →</button>`:`<div class="localnote">⚡ Copie de travail sur le Bureau : <b>${e(x.name)}</b></div><label>Commentaire<textarea id="com" placeholder="Commentaire"></textarea></label><button class="glow" onclick="finish('${x.id}','TRAITES',this)">✓ TRAITÉ</button><button class="danger" onclick="finish('${x.id}','NON_CONFORME',this)">! NON CONFORME</button>`}</div>`}
async function take(id,btn){
  const i=data.findIndex(v=>v.id===id);if(i<0)return;
  const before={...data[i]};
  // Optimistic UI: on sait deja quelle transition l'utilisateur vient de demander.
  data[i]={...data[i],status:'EN_COURS'};sel=data[i];fillFilters();render();pick(data[i].id);
  if(btn){btn.disabled=true;btn.textContent='Déplacement…'}
  try{
    const r=await req('/take',{method:'POST',body:JSON.stringify({id})});
    const cur=data.findIndex(v=>v.id===id);
    const x={...(cur>=0?data[cur]:before),id:r.id||id,status:'EN_COURS',fullPath:r.path||before.fullPath,desktopPath:r.desktopPath||''};
    if(cur>=0)data[cur]=x;else data.push(x);
    fillFilters();render();pick(x.id);
    if(r.copyOk===false)toast('EN COURS ✓ • copie Bureau non créée : '+(r.copyError||'erreur inconnue'),true);
    else toast('EN COURS ✓ • copie de travail créée sur le Bureau ⚡');
  }catch(err){
    const cur=data.findIndex(v=>v.id===id);if(cur>=0)data[cur]=before;fillFilters();render();pick(before.id);
    toast('Prise en charge impossible : '+err.message,true);
  }
}
let desktopChoice=null;
async function openDesktopPicker(){
  const modal=$('desktopModal'),list=$('desktopList'),ok=$('desktopOk');desktopChoice=null;ok.disabled=true;modal.classList.add('open');list.innerHTML='<div class="empty">Chargement du Bureau…</div>';
  try{const r=await req('/desktop');const items=Array.isArray(r.items)?r.items:[];list.innerHTML=items.map((x,n)=>`<button class="deskitem" data-name="${e(x.name)}" onclick="chooseDesktopItem(this)"><span>${x.isDirectory?'▰':'▤'}</span><b>${e(x.name)}</b><small>${x.isDirectory?'Dossier':'Fichier'}</small></button>`).join('')||'<div class="empty">Bureau vide.</div>'}catch(err){list.innerHTML='<div class="empty">'+e(err.message)+'</div>'}
  return new Promise(resolve=>{window._desktopResolve=resolve})
}
function chooseDesktopItem(el){document.querySelectorAll('.deskitem').forEach(x=>x.classList.remove('selected'));el.classList.add('selected');desktopChoice=el.dataset.name;$('desktopOk').disabled=false}
function closeDesktopPicker(value=null){$('desktopModal').classList.remove('open');const r=window._desktopResolve;window._desktopResolve=null;if(r)r(value)}
async function finish(id,status,btn){
  try{
    const desktopName=await openDesktopPicker();if(!desktopName)return;
    if(!confirm('Envoyer « '+desktopName+' » vers '+status.replace('_',' ')+' ?'))return;
    if(btn){btn.disabled=true;btn.textContent='Finalisation…'}
    const r=await req('/finish',{method:'POST',body:JSON.stringify({id,status,desktopName,comment:$('com')?.value||''})});
    data=data.filter(x=>x.id!==id);if(r.item)data.push(r.item);if(r.history)hist.push(r.history);sel=null;fillFilters();render();historyView();stats();$('detail').innerHTML='<div class="empty">Traitement finalisé. Sélectionnez un document.</div>';toast('Traitement finalisé • mise à jour locale instantanée ⚡')
  }catch(err){toast('Finalisation impossible : '+err.message,true)}finally{if(btn){btn.disabled=false;btn.textContent=status==='TRAITES'?'✓ TRAITÉ':'! NON CONFORME'}}
}
function nc(id){const x=data.find(y=>y.id===id);$('nclist').innerHTML=`<button onclick="render()">← Retour</button><div class="detailhead"><div class="fileicon">!</div><div><h3>${e(x.name)}</h3>${badge(x.status)}</div></div><div class="actions"><input id="desk2" placeholder="Nom du dossier corrigé sur le Bureau"><textarea id="com2" placeholder="Commentaire retraitement"></textarea><button class="glow" onclick="rework('${x.id}',this)">✓ Passer vers TRAITÉS</button></div>`}
async function rework(id,btn){const desktopFolder=$('desk2').value.trim();if(!desktopFolder)return toast('Nom du dossier Bureau requis.',true);try{btn.disabled=true;await req('/rework',{method:'POST',body:JSON.stringify({id,desktopFolder,comment:$('com2').value})});toast('Retraitement terminé');await load()}catch(x){toast(x.message,true);btn.disabled=false}}
function fm(m){if(m==null||!Number.isFinite(Number(m)))return'—';m=Math.round(Number(m));return Math.floor(m/60)+'h '+String(m%60).padStart(2,'0')}
function historyView(){const q=($('hq')?.value||'').toLowerCase(),a=hist.filter(x=>(`${x.name} ${x.domain} ${x.status}`).toLowerCase().includes(q));$('histlist').innerHTML=a.map(x=>`<article class="card"><div><b>${e(x.name)}</b>${badge(x.status)}</div><small>${e(x.domain)} · ${e(x.subdomain||'—')}</small><p>DMT : <b>${fm(x.dmtMinutes)}</b> · DMT2 : <b>${fm(x.dmt2Minutes)}</b></p></article>`).join('')||'<div class="empty">Aucun historique.</div>'}
function stats(){const f=hist.filter(x=>x.dateFin),d=f.map(x=>Number(x.dmtMinutes)).filter(Number.isFinite),d2=f.map(x=>Number(x.dmt2Minutes)).filter(Number.isFinite);$('st').textContent=f.length;$('sd').textContent=d.length?fm(d.reduce((a,b)=>a+b,0)/d.length):'—';$('sd2').textContent=d2.length?fm(d2.reduce((a,b)=>a+b,0)/d2.length):'—';$('sr').textContent=f.length?Math.round(f.filter(x=>x.status==='TRAITES').length/f.length*100)+'%':'—'}
function page(id,btn){['work','nc','hist','stats'].forEach(x=>$(x).classList.toggle('hide',x!==id));document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));btn?.classList.add('active');$('title').textContent={work:'Tableau de bord',nc:'Non conformes',hist:'Mon historique',stats:'Mes statistiques'}[id]}
$('q').addEventListener('input',render);$('domainFilter').addEventListener('change',()=>{fillFilters();render()});$('subdomainFilter').addEventListener('change',render);$('statusFilter').addEventListener('change',render);load();
