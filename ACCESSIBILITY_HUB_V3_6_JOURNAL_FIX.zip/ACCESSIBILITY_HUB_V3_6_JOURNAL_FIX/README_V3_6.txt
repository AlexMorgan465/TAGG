ACCESSIBILITY HUB V3.6 - JOURNAL FIX

- dateFin = instant exact de confirmation TRAITE / NON CONFORME.
- DMT = dateFin - dateEnCours.
- Compatibilite avec les anciens pilotage.json dont certaines proprietes sont absentes.
- Les proprietes dateFin, dmtMinutes, comment, dateRetraitement, dmt2Minutes, status2 sont ajoutees automatiquement si necessaire.
- Aucun rescan DP necessaire apres finalisation.
